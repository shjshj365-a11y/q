#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify-ipa.py —— 开签之前先验包(纯 Python,零依赖,Windows / mac / Linux 都能跑)

用法:
    python3 verify-ipa.py 蛋仔派对.ipa
    python3 verify-ipa.py 蛋仔_injected.ipa libEggyHack.dylib

它一次性回答四个问题:
    1. 这个包脱壳了吗?(FairPlay cryptid 是不是 0)
    2. 主二进制是哪些架构?(非越狱机器要纯 arm64)
    3. 主二进制里有没有我们要的 LC_LOAD_DYLIB?
    4. Frameworks/ 里有没有那个 dylib,它的架构对不对?

为什么必须验:
    · 没脱壳的包重签必然闪退 —— 先发现,省一趟白折腾
    · 架构不对(dylib 编成 arm64e / x86_64)必闪退,而且崩溃日志只指向 dyld,很难看出是架构问题
    · 已经注入过的包再注入一次 = dylib 加载两遍,起来就崩
    · 主二进制加了 load command 但 dylib 没放进 Frameworks/ = 同样起不来

不需要装任何东西 —— Mach-O 解析这段是自己写的,不依赖 lief / otool / Xcode。
"""

import argparse
import os
import plistlib
import struct
import sys
import tempfile
import zipfile

OK = "  [OK]   "
BAD = "  [!!]   "
INFO = "  [--]   "

# ---- Mach-O 常量 ----
MH_MAGIC = 0xFEEDFACE
MH_MAGIC_64 = 0xFEEDFACF
MH_CIGAM = 0xCEFAEDFE
MH_CIGAM_64 = 0xCFFAEDFE
FAT_MAGIC = 0xCAFEBABE
FAT_CIGAM = 0xBEBAFECA
FAT_MAGIC_64 = 0xCAFEBABF
FAT_CIGAM_64 = 0xBFBAFECA

LC_REQ_DYLD = 0x80000000
LC_ID_DYLIB = 0x0D
LC_LOAD_DYLIB = 0x0C
LC_LOAD_WEAK_DYLIB = 0x18 | LC_REQ_DYLD
LC_REEXPORT_DYLIB = 0x1F | LC_REQ_DYLD
LC_LOAD_UPWARD_DYLIB = 0x23 | LC_REQ_DYLD
LC_ENCRYPTION_INFO = 0x21
LC_ENCRYPTION_INFO_64 = 0x2C
LC_CODE_SIGNATURE = 0x1D

DYLIB_CMDS = {
    LC_LOAD_DYLIB: "load",
    LC_LOAD_WEAK_DYLIB: "load(weak)",
    LC_REEXPORT_DYLIB: "reexport",
    LC_LOAD_UPWARD_DYLIB: "load(upward)",
    LC_ID_DYLIB: "id",
}

CPU_MAP = {
    0x0100000C: "ARM64",
    0x0200000C: "ARM64E",
    0x01000007: "X86_64",
    0x00000007: "X86",
    0x0000000C: "ARM",
    0x00000012: "PPC",
    0x01000012: "PPC64",
}

FILETYPE_MAP = {
    1: "object", 2: "executable", 6: "dylib", 8: "bundle",
}


def cpu_name(cputype, cpusubtype=0):
    name = CPU_MAP.get(cputype)
    if name:
        return name
    return "0x%X" % cputype


def parse_fat(data):
    """
    FAT(通用)二进制:返回 [(cputype, offset, size), ...]
    注意 fat header 里的多字节整数是大端。
    """
    magic = struct.unpack_from(">I", data, 0)[0]
    if magic == FAT_MAGIC:
        endian, is64 = ">", False
    elif magic == FAT_MAGIC_64:
        endian, is64 = ">", True
    elif magic == FAT_CIGAM:
        endian, is64 = "<", False
    elif magic == FAT_CIGAM_64:
        endian, is64 = "<", True
    else:
        return None

    n = struct.unpack_from(endian + "I", data, 4)[0]
    if n <= 0 or n > 64:
        return None

    out = []
    off = 8
    for _ in range(n):
        if is64:
            if off + 32 > len(data):
                break
            cputype, sub, _, _, _, _ = struct.unpack_from(endian + "iiQQII", data, off)
            a_off, a_size = struct.unpack_from(endian + "QQ", data, off + 8)
            off += 32
        else:
            if off + 20 > len(data):
                break
            cputype, sub, a_off, a_size, _ = struct.unpack_from(endian + "iiIII", data, off)
            off += 20
        out.append((cputype, a_off, a_size))
    return out


def parse_thin(data, base=0):
    """
    解析一个 thin Mach-O。返回 dict 或 None。
    结构:
        header(32/28 字节) -> load commands(ncmds 条)
    """
    if base + 4 > len(data):
        return None
    magic = struct.unpack_from("<I", data, base)[0]

    if magic in (MH_MAGIC_64, MH_CIGAM_64):
        is64 = True
        endian = "<" if magic == MH_MAGIC_64 else ">"
        hdr_size = 32
    elif magic in (MH_MAGIC, MH_CIGAM):
        is64 = False
        endian = "<" if magic == MH_MAGIC else ">"
        hdr_size = 28
    else:
        return None

    if base + hdr_size > len(data):
        return None

    if is64:
        (_, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags, _) = \
            struct.unpack_from(endian + "IiiIIIII", data, base)
    else:
        (_, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags) = \
            struct.unpack_from(endian + "IiiIIII", data, base)

    info = {
        "offset": base,
        "is64": is64,
        "cputype": cputype,
        "cpusubtype": cpusubtype,
        "filetype": filetype,
        "arch": cpu_name(cputype, cpusubtype),
        "ncmds": ncmds,
        "cryptid": None,
        "libs": [],
        "signed": False,
        "cmds": [],
    }

    off = base + hdr_size
    for _ in range(ncmds):
        if off + 8 > len(data):
            break
        cmd, cmdsize = struct.unpack_from(endian + "II", data, off)
        if cmdsize < 8 or off + cmdsize > len(data):
            break

        # 加密信息段 —— 判断脱没脱壳的关键
        if cmd in (LC_ENCRYPTION_INFO, LC_ENCRYPTION_INFO_64):
            if off + 20 <= len(data):
                cryptid = struct.unpack_from(endian + "I", data, off + 16)[0]
                info["cryptid"] = cryptid

        # 代码签名段 —— 有没有都行,顺手记一下
        elif cmd == LC_CODE_SIGNATURE:
            info["signed"] = True

        # 依赖库
        elif cmd in DYLIB_CMDS:
            if off + 24 <= len(data):
                name_off = struct.unpack_from(endian + "I", data, off + 8)[0]
                start = off + name_off
                end = off + cmdsize
                if 0 < name_off < cmdsize and start < end:
                    raw = data[start:end]
                    raw = raw.split(b"\0", 1)[0]
                    try:
                        nm = raw.decode("utf-8", "replace")
                    except Exception:
                        nm = repr(raw)
                    info["libs"].append((DYLIB_CMDS[cmd], nm))

        info["cmds"].append(cmd)
        off += cmdsize

    return info


def parse_macho(data):
    """
    入口:自动识别 FAT / thin,返回 [info, ...]
    """
    if len(data) < 8:
        return []
    fat = parse_fat(data)
    if fat:
        out = []
        for cputype, off, size in fat:
            if off + 4 > len(data):
                continue
            info = parse_thin(data, off)
            if info:
                out.append(info)
        return out
    info = parse_thin(data, 0)
    return [info] if info else []


# Mach-O 的头和 load commands 全在文件最前面,游戏的主二进制可能几百 MB,
# 没必要整块读进来 —— 只取开头这一段就够判断了。
HEAD_LIMIT = 4 << 20      # 先读 4MB
SLICE_LIMIT = 1 << 20     # FAT 里靠后的架构,单独 seek 读 1MB


def collect_infos(zf, zi, head):
    """
    从"包头"里收集所有架构的信息。
    thin 二进制:包头里就有全部 load commands。
    FAT 二进制:如果某个架构的切片落在包头之外,就 seek 过去单独读。
    """
    fat = parse_fat(head)
    if not fat:
        info = parse_thin(head, 0)
        return [info] if info else []

    out = []
    for cputype, off, size in fat:
        if off + 32 <= len(head):
            info = parse_thin(head, off)
        else:
            try:
                with zf.open(zi) as f:
                    f.seek(off)
                    blob = f.read(SLICE_LIMIT + 32)
                info = parse_thin(blob, 0)
            except Exception:
                info = None
        if info:
            info["arch"] = cpu_name(info["cputype"], info["cpusubtype"])
            out.append(info)
    return out


def pick_app_dir(names):
    """IPA 结构固定是 Payload/<AppName>.app/"""
    for n in names:
        if n.startswith("Payload/") and n.count("/") == 2 and n.endswith(".app/"):
            return n
    for n in names:
        if n.startswith("Payload/") and ".app/" in n:
            return n[: n.index(".app/") + 5]
    return None


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return "%.1f %s" % (n, unit) if unit != "B" else "%d B" % n
        n /= 1024.0


def main():
    ap = argparse.ArgumentParser(description="开签之前验一下这个 IPA")
    ap.add_argument("ipa", help="要检查的 IPA")
    ap.add_argument("dylib", nargs="?", default=None,
                    help="可选:你打算注入的 dylib(文件名或路径),用来核对注入是否生效")
    args = ap.parse_args()

    if not os.path.isfile(args.ipa):
        sys.exit("[!] 找不到文件: %s" % args.ipa)

    want = os.path.basename(args.dylib) if args.dylib else None

    print("=" * 58)
    print(" 验包: %s" % os.path.basename(args.ipa))
    print("=" * 58)

    zin = zipfile.ZipFile(args.ipa, "r")
    names = zin.namelist()
    app_dir = pick_app_dir(names)
    if not app_dir:
        sys.exit("[!] 这个 zip 里没有 Payload/*.app,确认一下是不是 IPA")

    info_entry = app_dir + "Info.plist"
    if info_entry not in names:
        sys.exit("[!] 没找到 %s" % info_entry)

    pl = plistlib.loads(zin.read(info_entry))
    exe = pl.get("CFBundleExecutable")
    print("\n[包信息]")
    print(INFO + "App       : %s" % app_dir.rstrip("/"))
    print(INFO + "BundleID  : %s" % pl.get("CFBundleIdentifier", "?"))
    print(INFO + "主二进制  : %s" % exe)
    print(INFO + "最低系统  : iOS %s" % pl.get("MinimumOSVersion", "?"))
    print(INFO + "包体大小  : %s" % human(os.path.getsize(args.ipa)))

    if not exe:
        sys.exit("[!] Info.plist 里没有 CFBundleExecutable")
    exe_entry = app_dir + exe
    if exe_entry not in names:
        sys.exit("[!] 找不到主可执行文件: %s" % exe_entry)

    # 只读开头这一段 —— 主二进制可能几百 MB,整块读进来纯属浪费
    exe_info = zin.getinfo(exe_entry)
    with zin.open(exe_info) as f:
        head = f.read(HEAD_LIMIT)
    bins = collect_infos(zin, exe_info, head)
    if exe_info.file_size > len(head):
        print(INFO + "(主二进制 %s,只读了开头的元信息,没整块加载)"
              % human(exe_info.file_size))

    print("\n[1] 脱壳检查")
    if not bins:
        print(BAD + "认不出这个 Mach-O 格式,可能不是 iOS 的包")
        cryptids = []
    else:
        cryptids = [b["cryptid"] for b in bins]
        known = [c for c in cryptids if c is not None]
        if not known:
            print(OK + "所有架构都没有 LC_ENCRYPTION_INFO 段 —— 视为已脱壳")
            print(INFO + "(很多脱壳工具会直接把这段删掉,和 cryptid=0 一个意思)")
        elif any(c != 0 for c in known):
            bad = [b["arch"] for b in bins if b["cryptid"] not in (None, 0)]
            print(BAD + "还是加密的!%s 的 cryptid = %s" %
                  (", ".join(bad), [b["cryptid"] for b in bins if b["cryptid"] not in (None, 0)]))
            print(INFO + "加密包重签上去必闪退。先去搞脱壳包:")
            print(INFO + "  ① 网上流传的蛋仔脱壳 IPA(资源站常有人放)")
            print(INFO + "  ② 找有越狱机的朋友用 CrackerXI 帮你砸一下")
            print(INFO + "  ③ 租个越狱云机自己砸")
        else:
            print(OK + "全部架构 cryptid = 0 —— 已脱壳,可以往下走")

    print("\n[2] 主二进制架构")
    if not bins:
        print(INFO + "跳过")
        good_arch = False
    else:
        for b in bins:
            ft = FILETYPE_MAP.get(b["filetype"], str(b["filetype"]))
            print(INFO + "· %-7s  %s%s" % (b["arch"], ft, "(64位)" if b["is64"] else ""))
        archs = [b["arch"] for b in bins]
        good_arch = "ARM64" in archs
        if good_arch and "ARM64E" not in archs:
            print(OK + "含纯 arm64 —— 非越狱设备能跑")
        elif "ARM64E" in archs and "ARM64" not in archs:
            print(BAD + "只有 arm64e。arm64e 在非越狱自签下加载不了,")
            print(INFO + "需要把 arm64 那一份抽出来(lipo -thin arm64)。")
        elif "ARM64E" in archs:
            print(INFO + "同时有 arm64 和 arm64e —— 系统按设备挑,一般没问题")
        elif "X86_64" in archs or "X86" in archs:
            print(BAD + "只有模拟器架构,这是给电脑跑的包,装不到手机上")

    print("\n[3] 注入检查")
    injected = None
    if not bins:
        print(INFO + "跳过")
    else:
        all_libs = []
        for b in bins:
            for kind, nm in b["libs"]:
                all_libs.append((b["arch"], kind, nm))
        custom = [x for x in all_libs
                  if x[2].startswith("@executable_path")
                  or x[2].startswith("@loader_path")
                  or "/Frameworks/" in x[2]]
        sys_libs = [x for x in all_libs if x not in custom]

        if sys_libs:
            print(INFO + "系统库依赖 %d 条(正常,不用管)" % len(sys_libs))
        if custom:
            print(INFO + "自定义依赖:")
            for arch, kind, nm in custom:
                print("         · [%s] %s  %s" % (arch, kind, nm))
        else:
            print(INFO + "没有任何自定义依赖 —— 这是个干净未注入的包")

        if want:
            hit = [x for x in custom if want in x[2]]
            injected = bool(hit)
            if hit:
                print(OK + "注入生效: %s" % hit[0][2])
            else:
                if any(want in nm for _, _, nm in all_libs):
                    print(INFO + "load command 里没有,但要留神路径写法(可能是相对路径)")
                print(BAD + "没找到 %s 这条 load command —— 还没注入" % want)
        else:
            print(INFO + "想核对注入结果就带上第二个参数,例如:")
            print(INFO + "  python3 verify-ipa.py 包.ipa libEggyHack.dylib")

    print("\n[4] Frameworks/ 里的东西")
    fw_dir = app_dir + "Frameworks/"
    fw = [n for n in names
          if n.startswith(fw_dir) and n[len(fw_dir):] and "/" not in n[len(fw_dir):]]
    names_in_fw = [n[len(fw_dir):] for n in fw]
    fw_ok = (want in names_in_fw) if want else None
    dylib_bad = None

    if not fw:
        if want and injected:
            print(BAD + "Frameworks/ 是空的 —— 主二进制指向一个不存在的库,装上必崩")
            print(INFO + "把 %s 放进 Payload/*.app/Frameworks/ 再签" % want)
        else:
            print(INFO + "Frameworks/ 是空的(还没注入过,这是正常的)")
    else:
        for n in fw:
            base = n[len(fw_dir):]
            blob = zin.read(n)
            tag = ""
            sub = parse_macho(blob)
            if sub:
                ft = FILETYPE_MAP.get(sub[0]["filetype"], "")
                tag = "  [%s %s]" % (",".join(x["arch"] for x in sub), ft)
            print(INFO + "· %-28s %8s%s" % (base, human(len(blob)), tag))

    if want and fw_ok:
        blob = zin.read(fw_dir + want)
        sub = parse_macho(blob)
        if sub:
            a = [x["arch"] for x in sub]
            print(INFO + "dylib 架构: %s" % ", ".join(a))
            if "ARM64" in a:
                print(OK + "架构里有 arm64,设备能加载")
            else:
                print(BAD + "没有纯 arm64!非越狱设备加载不了 —— 重新编一份 arm64 的")
                dylib_bad = "dylib 架构不对"
            if sub[0]["filetype"] != 6:
                print(BAD + "这个文件不是 dylib(MH_DYLIB=6)—— dyld 会直接拒绝加载")
                dylib_bad = dylib_bad or "不是 dylib 文件"
            if sub[0]["cryptid"] not in (None, 0):
                print(BAD + "这个 dylib 自己还是加密的 —— 它是从 App Store 包里直接抠出来的")
                print(INFO + "      加密的 dylib 加载不了,得用砸壳后的那份")
                dylib_bad = dylib_bad or "dylib 未脱壳"
    elif not want:
        print(INFO + "想核对注入结果就带上第二个参数,例如:")
        print(INFO + "  python3 verify-ipa.py 包.ipa libEggyHack.dylib")

    print("\n" + "=" * 58)
    if not bins:
        print(" 结论:包结构不对劲,先确认这是不是个正常的 IPA")
    elif any(c not in (None, 0) for c in cryptids):
        print(" 结论:包没脱壳 —— 先解决脱壳,别的都白搭")
    elif want and injected is False:
        print(" 结论:还没注入 —— 先跑 inject-ipa.py,再回来验一次")
    elif want and injected and not fw_ok:
        print(" 结论:load command 有了,但 Frameworks/ 里缺 dylib —— 装上必崩,补进去")
    elif want and dylib_bad:
        print(" 结论:注入结构对了,但 dylib 本身有问题(%s)—— 先处理它" % dylib_bad)
    elif want and injected and fw_ok:
        print(" 结论:注入完整,可以直接拿去签名了")
    elif not want and not good_arch:
        print(" 结论:架构有问题,先处理架构")
    else:
        print(" 结论:包本身没问题,可以拿去签名")
        if not want:
            print("       (带上 dylib 名字再跑一次,可以顺带核对注入对不对)")
    print("=" * 58)
    print("")


if __name__ == "__main__":
    main()
