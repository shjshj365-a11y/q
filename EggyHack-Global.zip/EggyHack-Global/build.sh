#!/usr/bin/env bash
#
# 编 dylib —— 只有一条 clang 命令,不需要 Theos,不需要 substrate。
#
# 用法:  bash build.sh
# 产物:  libEggyHack.dylib   (在本目录下)
#
# 必须在有 Xcode 的 macOS 上跑。没有电脑?把工程推到 GitHub,
# 仓库自带的 Actions 会自动跑这个脚本,产物在 Artifacts 里下。

set -euo pipefail

cd "$(dirname "$0")"

OUT="${OUT:-libEggyHack.dylib}"
MIN_IOS="${MIN_IOS:-15.0}"
ARCH="${ARCH:-arm64}"          # 非越狱设备就是 arm64;arm64e 别塞进去

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "SDK     = $SDK"
echo "产物    = $OUT"
echo "架构    = $ARCH  最低系统 = iOS $MIN_IOS"
echo

SRCS=$(ls src/*.m)
echo "源文件:"
echo "$SRCS" | sed 's/^/  /'
echo

clang \
  -arch "$ARCH" \
  -isysroot "$SDK" \
  -miphoneos-version-min="$MIN_IOS" \
  -dynamiclib \
  -fobjc-arc \
  -O2 \
  -fvisibility=hidden \
  -Wno-deprecated-declarations \
  -Wno-unused-function \
  -install_name "@executable_path/Frameworks/${OUT}" \
  -framework Foundation \
  -framework UIKit \
  -framework QuartzCore \
  -framework CoreGraphics \
  -Wl,-dead_strip \
  -o "$OUT" \
  $SRCS

# 去掉本地符号,少留特征
strip -x "$OUT" 2>/dev/null || true

echo "---- 结果 ----"
lipo -info "$OUT"
echo
echo "---- 依赖(应该只有系统库,不能有 substrate)----"
otool -L "$OUT"
echo
echo "---- 确认没链接 substrate ----"
if otool -L "$OUT" | grep -qi substrate; then
    echo "!!!! 竟然链了 substrate,非越狱设备上会加载失败"
    exit 1
fi
echo "OK,干净。"

echo
echo "搞定:$(pwd)/$OUT"
