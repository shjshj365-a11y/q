#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
inject-ipa.py —— 给 IPA 注入 dylib(纯 Python,Windows / Linux / macOS 都能跑)

用法:
    python3 inject-ipa.py 蛋仔派对.ipa libEggyHack.dylib -o 蛋仔派对_injected.ipa
    python3 inject-ipa.py 蛋仔派对.ipa libEggyHack.dylib              # 自动命名 *_injected.ipa

它做了四件事:
    1. 读 Payload/xxx.app/Info.plist,拿到 CFBundleExecutable(主可执行文件名)
    2. 给主可执行文件加一条 LC_LOAD_DYLIB -> @executable_path/Frameworks/<dylib 文件名>
    3. 把 dylib 放进 Payload/xxx.app/Frameworks/
    4. 重新打包(原 zip 里所有条目 / 权限 / 符号链接全部照搬,不破坏 IPA 结构)

依赖:
    pip install lief

⚠️ 输入必须是【已脱壳】的 IPA。
   App Store 直接导出的包是 FairPlay 加密的,加密段要靠"原始签名"才能解,
   你一重签解密链路就断 —— 改过的加密包装上去必闪退。
"""

import argparse
import contextlib
import os
import plistlib
import shutil
import sys
import tempfile
import zipfile

DIR_ATTR = (0o040755 << 16) | 0x10
FILE_ATTR = (0o100755 << 16) | 0x20


@contextlib.contextmanager
def quiet_fd():
    """
    底层库偶尔会往 stdout 打 'No signature found' 之类的话,
    这在正常流程里是预期结果(原包本来就没签名),但看起来像报错。
    临时把 fd 1/2 指到空设备,打完就还原。
    """
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass

    saved = []
    devnull = None
    try:
        devnull = os.open(os.devnull, os.O_WRONLY)
        for fd in (1, 2):
            saved.append((fd, os.dup(fd)))
            os.dup2(devnull, fd)
    except Exception:
        # 输出被重定向到非 fd 的地方(比如 IDE 里),静音失败就照常输出
        for fd, old in saved:
            try:
                os.dup2(old, fd)
                os.close(old)
            except Exception:
                pass
        if devnull is not None:
            os.close(devnull)
        yield
        return

    try:
        yield
    finally:
        for fd, old in saved:
            try:
                os.dup2(old, fd)
                os.close(old)
            except Exception:
                pass
        try:
            os.close(devnull)
        except Exception:
            pass


def load_lief():
    try:
        import lief
        return lief
    except ImportError:
        sys.exit("[!] 缺 lief 这个库。先跑:pip install lief")


def pick_app_dir(names):
    """IPA 结构固定是 Payload/<AppName>.app/,这里把它找出来。"""
    for n in names:
        if not n.startswith("Payload/"):
            continue
        if n.count("/") == 2 and n.endswith(".app/"):
            return n
    # 有的包没有显式目录条目,退一步从文件路径推
    for n in names:
        if n.startswith("Payload/") and ".app/" in n:
            return n[: n.index(".app/") + 5]
    return None


def parse_fat(lief, path):
    """
    LIEF 的 FatBinary 在旧版里不能直接迭代,这里做个兼容。
    返回 list[arch]
    """
    fat = lief.MachO.parse(path)
    if fat is None:
        return None, None
    try:
        archs = list(fat)
    except TypeError:
        archs = []
        for i in range(fat.size):
            b = fat.at(i)
            if b is not None:
                archs.append(b)
    return fat, archs


def patch_binary(lief, path, dylib_name):
    """给 Mach-O 加 LC_LOAD_DYLIB,顺手把原来的签名删掉(后面反正要重签)。"""
    load_cmd = "@executable_path/Frameworks/" + dylib_name

    fat, archs = parse_fat(lief, path)
    if fat is None or not archs:
        sys.exit("[!] LIEF 认不出这个 Mach-O,可能不是标准 arm64 包")

    added = 0
    for b in archs:
        # 已经有这条 load command 就别重复加(加两次会加载两次)
        try:
            if b.has_library(load_cmd):
                print("    · 这个架构已经有这条 load command,跳过")
                continue
        except Exception:
            pass

        try:
            b.add_library(load_cmd)
            added += 1
            print("    · 已加 LC_LOAD_DYLIB: %s" % load_cmd)
        except Exception as e:
            print("    ! 加 load command 失败: %s" % e)

        # 旧签名留着也没用,删掉免得干扰后面重签
        with quiet_fd():
            try:
                b.remove_signature()
            except Exception:
                pass

    if added == 0:
        sys.exit("[!] 一条都没加上,可能这个二进制本身已经注入过了")

    try:
        fat.write(path)
    except Exception as e:
        sys.exit("[!] 写回二进制失败: %s" % e)

    return added


def copy_entry(dst, zin, zi, data):
    """按原样把一条 zip 条目复制过去(保留压缩方式 / 权限 / 符号链接属性)。"""
    new = zipfile.ZipInfo(zi.filename, zi.date_time)
    new.compress_type = zi.compress_type
    new.external_attr = zi.external_attr
    new.internal_attr = zi.internal_attr
    new.create_system = zi.create_system
    new.comment = zi.comment
    dst.writestr(new, data)


def new_entry(zi):
    """照抄一条 zip 条目的元信息(压缩方式 / 权限 / 时间戳),内容另写。"""
    new = zipfile.ZipInfo(zi.filename, zi.date_time)
    method = zi.compress_type
    if method not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
        method = zipfile.ZIP_DEFLATED
    new.compress_type = method
    new.external_attr = zi.external_attr
    new.internal_attr = zi.internal_attr
    new.create_system = zi.create_system
    new.comment = zi.comment
    return new


def copy_entry_stream(dst, zin, zi):
    """
    流式复制一条 zip 条目。
    游戏包动辄几个 G,整块 read() 进内存会直接吃爆 —— 这里按 1MB 一块倒。
    """
    new = new_entry(zi)
    if zi.is_dir():
        dst.writestr(new, b"")
        return 0

    total = 0
    try:
        with zin.open(zi) as src, dst.open(new, "w") as out_f:
            while True:
                chunk = src.read(1 << 20)
                if not chunk:
                    break
                out_f.write(chunk)
                total += len(chunk)
    except NotImplementedError:
        # 极少数包会用 zipfile 不支持写的压缩算法,退回普通方式
        return None

    # 如果新条目实际是 STORED,把大小补对(不然有些解包器会报错)
    return total


def main():
    ap = argparse.ArgumentParser(description="给 IPA 注入 dylib(跨平台)")
    ap.add_argument("ipa", help="已脱壳的 IPA")
    ap.add_argument("dylib", help="要注入的 dylib")
    ap.add_argument("-o", "--out", default=None, help="输出 IPA 路径")
    args = ap.parse_args()

    if not os.path.isfile(args.ipa):
        sys.exit("[!] 找不到 IPA: %s" % args.ipa)
    if not os.path.isfile(args.dylib):
        sys.exit("[!] 找不到 dylib: %s" % args.dylib)

    lief = load_lief()
    dylib_name = os.path.basename(args.dylib)
    out = args.out or (os.path.splitext(args.ipa)[0] + "_injected.ipa")
    out = os.path.abspath(out)

    print("[*] 打开: %s" % args.ipa)
    zin = zipfile.ZipFile(args.ipa, "r")
    names = zin.namelist()

    app_dir = pick_app_dir(names)
    if not app_dir:
        sys.exit("[!] 这个 zip 里没找到 Payload/*.app,确认一下是不是 IPA")

    info_entry = app_dir + "Info.plist"
    if info_entry not in names:
        sys.exit("[!] 没找到 %s" % info_entry)

    try:
        info = plistlib.loads(zin.read(info_entry))
    except Exception as e:
        sys.exit("[!] Info.plist 解析失败: %s" % e)

    exe = info.get("CFBundleExecutable")
    if not exe:
        sys.exit("[!] Info.plist 里没有 CFBundleExecutable")

    exe_entry = app_dir + exe
    if exe_entry not in names:
        sys.exit("[!] 没找到主可执行文件: %s" % exe_entry)

    bundle_id = info.get("CFBundleIdentifier", "?")
    print("[*] App: %s" % app_dir)
    print("[*] BundleID: %s" % bundle_id)
    print("[*] 主二进制: %s" % exe_entry)

    # ---- 1. 把主二进制抠出来打补丁 ----
    tmpdir = tempfile.mkdtemp(prefix="eggy-inject-")
    raw = os.path.join(tmpdir, exe)
    with open(raw, "wb") as f:
        f.write(zin.read(exe_entry))

    print("[*] 打补丁...")
    patch_binary(lief, raw, dylib_name)

    # ---- 2. 重新打包 ----
    print("[*] 重新打包: %s" % out)
    fw_dir = app_dir + "Frameworks/"
    need_fw_dir = fw_dir not in names

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        total_entries = len(zin.infolist())
        done = 0
        for zi in zin.infolist():
            if zi.filename == exe_entry:
                continue  # 主二进制用打过补丁的那份,单独写
            r = copy_entry_stream(zout, zin, zi)
            if r is None:
                copy_entry(zout, zin, zi, zin.read(zi.filename))
            done += 1
            # 大包要跑好几分钟,给个进度免得以为卡死了
            if done % 200 == 0:
                print("    · 已处理 %d/%d 个文件" % (done, total_entries))

        # 万一原本没有 Frameworks 目录,补一个目录条目
        if need_fw_dir:
            d = zipfile.ZipInfo(fw_dir, (1980, 1, 1, 0, 0, 0))
            d.compress_type = zipfile.ZIP_STORED
            d.external_attr = DIR_ATTR
            d.create_system = 3
            zout.writestr(d, b"")

        # 打过补丁的主二进制,继承它原来的 zip 属性
        orig = zin.getinfo(exe_entry)
        with open(raw, "rb") as f:
            copy_entry(zout, zin, orig, f.read())

        # dylib
        target = fw_dir + dylib_name
        zi = zipfile.ZipInfo(target, (1980, 1, 1, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = FILE_ATTR
        zi.create_system = 3
        with open(args.dylib, "rb") as f:
            zout.writestr(zi, f.read())

    zin.close()

    size = os.path.getsize(out) / 1024.0 / 1024.0
    print("")
    print("[OK] 注入完成: %s (%.1f MB)" % (out, size))
    print("     dylib 落点: %s" % target)
    print("")
    print("下一步:重签,否则装不上 ——")
    print("    ./sign-ipa.sh \"%s\" 证书.p12 证书密码 描述文件.mobileprovision" % out)
    print("")


if __name__ == "__main__":
    main()
