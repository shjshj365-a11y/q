//
//  ZKMem.m
//

#import "ZKMem.h"
#import "ZKConfig.h"

#import <mach/mach.h>
#import <mach-o/dyld.h>
#import <libkern/OSCacheControl.h>
#import <string.h>
#import <stdlib.h>

/* ============================================================
   镜像
   ============================================================ */

uintptr_t zk_image_base(const char *imgName)
{
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *path = _dyld_get_image_name(i);
        if (path && strstr(path, imgName)) {
            return (uintptr_t)_dyld_get_image_header(i);
        }
    }
    return 0;
}

const char *zk_image_path(const char *imgName)
{
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; i++) {
        const char *path = _dyld_get_image_name(i);
        if (path && strstr(path, imgName)) return path;
    }
    return NULL;
}

uintptr_t zk_main_base(void)
{
    return (uintptr_t)_dyld_get_image_header(0);
}

/* ============================================================
   区域查询 + 权限
   ============================================================ */

static bool zk_region(addr_t addr, vm_size_t *outSize, vm_prot_t *outProt)
{
    vm_address_t region = addr;
    vm_size_t size = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t object = MACH_PORT_NULL;

    kern_return_t kr = vm_region_64(mach_task_self(), &region, &size,
                                    VM_REGION_BASIC_INFO_64,
                                    (vm_region_info_t)&info, &count, &object);

    if (kr != KERN_SUCCESS) return false;
    if (outSize) *outSize = size;
    if (outProt) *outProt = info.protection;
    return true;
}

static bool zk_set_prot(void *addr, size_t len, vm_prot_t prot)
{
    vm_address_t start = (vm_address_t)addr;
    vm_address_t end   = start + len;

    vm_address_t region = start;
    while (region < end) {
        vm_size_t size = 0;
        if (!zk_region(region, &size, NULL)) return false;
        if (size == 0) return false;
        if (mach_vm_protect(mach_task_self(), region, size, FALSE, prot) != KERN_SUCCESS) {
            return false;
        }
        region += size;
    }
    return true;
}

bool zk_make_writable(void *addr, size_t len)
{
    if (!addr) return false;

    vm_prot_t prot = 0;
    if (!zk_region((addr_t)addr, NULL, &prot)) return false;

    /* 已经是可写就直接过 */
    if ((prot & VM_PROT_WRITE) && !(prot & VM_PROT_EXECUTE)) return true;

    /*
     * 代码段要走 VM_PROT_COPY 强制 COW:直接给写权限会改到所有进程共享的
     * 物理页,只在当前进程里改一份拷贝才安全。
     */
    vm_prot_t want = prot | VM_PROT_WRITE;
    if (prot & VM_PROT_EXECUTE) want |= VM_PROT_COPY;

    return zk_set_prot(addr, len, want);
}

/* ============================================================
   读写
   ============================================================ */

bool zk_mem_write(void *addr, const void *data, size_t len)
{
    if (!addr || !data || len == 0) return false;
    if (!zk_make_writable(addr, len)) return false;
    memcpy(addr, data, len);
    return true;
}

bool zk_mem_read(const void *addr, void *out, size_t len)
{
    if (!addr || !out || len == 0) return false;
    memcpy(out, addr, len);
    return true;
}

bool zk_safe_read(const void *addr, void *out, size_t len)
{
    if (!addr || !out || len == 0) return false;

    vm_prot_t prot = 0;
    if (!zk_region((addr_t)addr, NULL, &prot)) return false;
    if (!(prot & VM_PROT_READ)) return false;

    memcpy(out, addr, len);
    return true;
}

bool zk_looks_like_obj(const void *p)
{
    if (!p) return false;

    uintptr_t klass = 0;
    if (!zk_safe_read(p, &klass, sizeof(klass))) return false;
    if (klass < 0x1000) return false;

    vm_size_t size = 0;
    vm_prot_t prot = 0;
    if (!zk_region((addr_t)klass, &size, &prot)) return false;
    if (!(prot & VM_PROT_READ)) return false;

    return true;
}

/* ============================================================
   代码补丁
   ============================================================ */

bool zk_patch_bytes(void *addr, const void *bytes, size_t len)
{
    if (!addr || !bytes || len == 0) return false;

    vm_prot_t prot = 0;
    if (!zk_region((addr_t)addr, NULL, &prot)) return false;

    if (!zk_make_writable(addr, len)) return false;

    memcpy(addr, bytes, len);

    /* 指令缓存必须刷,不然 CPU 还可能跑旧指令 */
    sys_icache_invalidate(addr, len);

    /* 改完把权限收回去,少留痕迹 */
    vm_prot_t back = prot;
    if (prot & VM_PROT_EXECUTE) back = (prot & ~VM_PROT_WRITE);
    zk_set_prot(addr, len, back);

    return true;
}

bool zk_patch_save(void *addr, uint8_t out[8])
{
    if (!addr || !out) return false;
    return zk_safe_read(addr, out, 8);
}

bool zk_patch_restore(void *addr, const uint8_t saved[8])
{
    if (!addr || !saved) return false;
    return zk_patch_bytes(addr, saved, 8);
}

bool zk_patch_insn(void *addr, uint32_t insn)
{
    return zk_patch_bytes(addr, &insn, sizeof(insn));
}

bool zk_patch_nop(void *addr, int count)
{
    for (int i = 0; i < count; i++) {
        if (!zk_patch_insn((uint8_t *)addr + i * 4, ZK_ARM64_NOP)) return false;
    }
    return true;
}

bool zk_patch_ret(void *addr)
{
    return zk_patch_insn(addr, ZK_ARM64_RET);
}

bool zk_patch_return_false(void *addr)
{
    /* mov w0, #0 ; ret */
    uint32_t insns[2] = { ZK_ARM64_MOV_W0_0, ZK_ARM64_RET };
    return zk_patch_bytes(addr, insns, sizeof(insns));
}

bool zk_patch_return_true(void *addr)
{
    uint32_t insns[2] = { ZK_ARM64_MOV_W0_1, ZK_ARM64_RET };
    return zk_patch_bytes(addr, insns, sizeof(insns));
}

/* ============================================================
   ARM64 编码
   ============================================================ */

uint32_t zk_arm64_movz_w(uint8_t rd, uint16_t imm, uint8_t shift)
{
    uint32_t hw = (shift / 16) & 0x3;
    return 0x52800000u | (hw << 21) | ((uint32_t)(imm & 0xFFFF) << 5) | (rd & 0x1F);
}

uint32_t zk_arm64_mov_w0(uint16_t imm)
{
    return zk_arm64_movz_w(0, imm, 0);
}
