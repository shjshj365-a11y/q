//
//  ZKUI.h
//  UI 小工具
//

#ifndef ZK_UI_H
#define ZK_UI_H

#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

/// 拿当前活跃的窗口场景(iOS 13+ 建窗口必须带 scene,不然不显示)。
UIWindowScene *zk_active_window_scene(void);

/// 建一个悬挂在自己 scene 上的窗口。
UIWindow *zk_make_overlay_window(CGFloat levelOffset);

#ifdef __cplusplus
}
#endif

#endif /* ZK_UI_H */
