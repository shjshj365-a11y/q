//
//  ZKEngine.h
//  引擎:运行时自适配扫描 + 功能驱动(实时改内存)
//

#ifndef ZK_ENGINE_H
#define ZK_ENGINE_H

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

typedef struct ZKEspBox {
    float x, y, w, h;      /* 屏幕坐标(UIKit 点,左上原点) */
    float dist;
    int   isLocal;
    int   isEnemy;         /* 队伍判定成功且不同队 = 1;没数据 = -1 */
    char  label[28];
} ZKEspBox;

@interface ZKEngine : NSObject

+ (instancetype)shared;

/// 挂载:等 Unity 起来 → 扫描 → 起驱动。主线程调用。
- (void)bootstrap;

/* ---------- 功能开关(悬浮窗直接读写) ---------- */
@property (nonatomic, assign) BOOL espOn;
@property (nonatomic, assign) BOOL flyOn;
@property (nonatomic, assign) BOOL noclipOn;
@property (nonatomic, assign) BOOL speedOn;
@property (nonatomic, assign) BOOL cooldownOn;
@property (nonatomic, assign) BOOL markLocalOn;     /* 高亮本地玩家(自检用) */

@property (nonatomic, assign) float speedMul;       /* 1.0 ~ 2.5 */
@property (nonatomic, assign) float flySpeed;       /* 0.5 ~ 8.0 */
@property (nonatomic, assign) int   flyMode;        /* 0 悬停 / 1 上升 / 2 下降 */
@property (nonatomic, assign) float flyHeightStep;  /* 每次上升下降用,不用管 */

/* ---------- 状态 ---------- */
@property (nonatomic, readonly) BOOL scanDone;
@property (nonatomic, readonly) BOOL localPlayerFound;   /* 本地玩家有没有认出来 */
@property (nonatomic, readonly) BOOL cameraFound;
@property (nonatomic, readonly) int  entityCount;        /* 这帧扫到几个实体 */
@property (nonatomic, readonly) int  espCount;           /* 这帧画了几个框 */
@property (nonatomic, readonly) BOOL speedBound;         /* 移速字段绑上没有 */
@property (nonatomic, readonly) BOOL noclipBound;
@property (nonatomic, readonly) BOOL cooldownBound;
@property (nonatomic, readonly) int  antiCheatPatched;   /* 已 patch 的反作弊方法数 */
@property (nonatomic, readonly) BOOL antiBanOn;

/// 悬浮窗里那几行状态文字。
- (NSArray<NSString *> *)statusLines;

/// 导出完整扫描报告(给开发者填精确类名用)。
- (NSString *)fullReport;
- (BOOL)exportReport;
- (NSString *)reportPath;

/* ---------- ESP 取数据(画框线程调用) ---------- */
- (int)fillBoxes:(ZKEspBox *)buf max:(int)maxCount;

/* ---------- 防封总开关(放这里方便悬浮窗统一控制) ---------- */
- (void)setAntiBanEnabled:(BOOL)on;

@end

#endif /* ZK_ENGINE_H */
