//
//  ZKESP.m
//

#import "ZKESP.h"
#import "ZKEngine.h"
#import "ZKUI.h"
#import "ZKConfig.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define ZK_ESP_MAX_BOXES 64

/* ============================================================
   画布
   ============================================================ */

@interface ZKEspCanvas : UIView
@end

@implementation ZKEspCanvas
{
    CADisplayLink *_link;
    ZKEspBox      _boxes[ZK_ESP_MAX_BOXES];
    int           _count;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.backgroundColor = [UIColor clearColor];
    self.opaque = NO;
    self.userInteractionEnabled = NO;
    self.clearsContextDrawing = YES;

    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick)];
    _link.preferredFramesPerSecond = 30;
    [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

    return self;
}

- (void)tick
{
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    _count = [[ZKEngine shared] fillBoxes:_boxes max:ZK_ESP_MAX_BOXES];
    if (_count <= 0) return;

    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;

    CGContextSetLineWidth(ctx, 1.6);

    UIFont *font = [UIFont boldSystemFontOfSize:10];

    for (int i = 0; i < _count; i++) {
        ZKEspBox *b = &_boxes[i];

        UIColor *color;
        if (b->isLocal)            color = [UIColor colorWithRed:0.10 green:0.90 blue:1.00 alpha:1.0];
        else if (b->isEnemy == 1)  color = [UIColor colorWithRed:1.00 green:0.28 blue:0.28 alpha:1.0];
        else if (b->isEnemy == 0)  color = [UIColor colorWithRed:0.30 green:1.00 blue:0.45 alpha:1.0];
        else                       color = [UIColor colorWithRed:1.00 green:0.85 blue:0.20 alpha:1.0];

        CGRect r = CGRectMake(b->x, b->y, b->w, b->h);
        if (r.size.width < 4 || r.size.height < 4) continue;

        /* 方框 */
        CGContextSetStrokeColorWithColor(ctx, color.CGColor);
        CGContextStrokeRect(ctx, r);

        /* 四角加粗,看起来清楚点 */
        CGFloat corner = MAX(6.0f, r.size.width * 0.25f);
        CGContextSetLineWidth(ctx, 2.6);
        CGContextMoveToPoint(ctx, CGRectGetMinX(r), CGRectGetMinY(r) + corner);
        CGContextAddLineToPoint(ctx, CGRectGetMinX(r), CGRectGetMinY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMinX(r) + corner, CGRectGetMinY(r));

        CGContextMoveToPoint(ctx, CGRectGetMaxX(r) - corner, CGRectGetMinY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(r), CGRectGetMinY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(r), CGRectGetMinY(r) + corner);

        CGContextMoveToPoint(ctx, CGRectGetMinX(r), CGRectGetMaxY(r) - corner);
        CGContextAddLineToPoint(ctx, CGRectGetMinX(r), CGRectGetMaxY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMinX(r) + corner, CGRectGetMaxY(r));

        CGContextMoveToPoint(ctx, CGRectGetMaxX(r) - corner, CGRectGetMaxY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(r), CGRectGetMaxY(r));
        CGContextAddLineToPoint(ctx, CGRectGetMaxX(r), CGRectGetMaxY(r) - corner);
        CGContextStrokePath(ctx);

        CGContextSetLineWidth(ctx, 1.6);

        /* 距离文字 */
        NSString *label = [NSString stringWithUTF8String:b->label];
        if (label.length) {
            [label drawAtPoint:CGPointMake(CGRectGetMinX(r), CGRectGetMinY(r) - 12)
                withAttributes:@{ NSFontAttributeName: font,
                                  NSForegroundColorAttributeName: color }];
        }
    }
}

@end

/* ============================================================
   安装
   ============================================================ */

static UIWindow *g_espWindow = nil;

@implementation ZKESPView

+ (void)install
{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        g_espWindow = zk_make_overlay_window(100);
        g_espWindow.userInteractionEnabled = NO;

        ZKEspCanvas *canvas = [[ZKEspCanvas alloc] initWithFrame:g_espWindow.bounds];
        canvas.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [g_espWindow.rootViewController.view addSubview:canvas];

        ZKLOG(@"透视层已建");
    });
}

@end
