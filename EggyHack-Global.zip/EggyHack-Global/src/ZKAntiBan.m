//
//  ZKAntiBan.m
//

#import "ZKAntiBan.h"
#import "ZKIL2CPP.h"
#import "ZKMem.h"
#import "ZKConfig.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <string.h>

/* ============================================================
   可疑路径 / URL scheme
   ============================================================ */

static const char *kSuspiciousPaths[] = {
    "/Applications/Cydia.app",
    "/Applications/Sileo.app",
    "/Applications/Zebra.app",
    "/Library/MobileSubstrate/MobileSubstrate.dylib",
    "/Library/MobileSubstrate/DynamicLibraries",
    "/usr/sbin/sshd",
    "/usr/bin/ssh",
    "/usr/bin/sftp",
    "/bin/bash",
    "/etc/apt",
    "/etc/ssh/sshd_config",
    "/private/var/lib/apt",
    "/private/var/lib/cydia",
    "/private/var/cache/apt",
    "/private/var/stash",
    "/var/jb",
    "/var/lib/dpkg",
    "/var/lib/cydia",
    "/var/cache/apt",
    "/private/preboot",
    NULL
};

static BOOL zk_path_is_suspicious(NSString *path)
{
    if (![path isKindOfClass:[NSString class]] || path.length == 0) return NO;

    const char *p = path.UTF8String;
    for (int i = 0; kSuspiciousPaths[i]; i++) {
        if (strstr(p, kSuspiciousPaths[i]) != NULL) return YES;
    }
    /* Frida / 调试器常用的东西 */
    if (strstr(p, "frida") || strstr(p, "cycript") || strstr(p, "substrate")) return YES;

    return NO;
}

/* ============================================================
   ObjC 层:文件检测 / URL scheme 检测
   ============================================================ */

static BOOL (*orig_fileExists)(id, SEL, NSString *);
static BOOL (*orig_fileExistsIsDir)(id, SEL, NSString *, BOOL *);
static BOOL (*orig_canOpenURL)(id, SEL, NSURL *);

static BOOL zk_fileExists(id self, SEL _cmd, NSString *path)
{
    if (zk_path_is_suspicious(path)) return NO;
    return orig_fileExists ? orig_fileExists(self, _cmd, path) : NO;
}

static BOOL zk_fileExistsIsDir(id self, SEL _cmd, NSString *path, BOOL *isDir)
{
    if (zk_path_is_suspicious(path)) {
        if (isDir) *isDir = NO;
        return NO;
    }
    return orig_fileExistsIsDir ? orig_fileExistsIsDir(self, _cmd, path, isDir) : NO;
}

static BOOL zk_canOpenURL(id self, SEL _cmd, NSURL *url)
{
    NSString *s = url.absoluteString.lowercaseString;
    if (s) {
        if ([s hasPrefix:@"cydia://"] || [s hasPrefix:@"sileo://"] ||
            [s hasPrefix:@"zebra://"]  || [s hasPrefix:@"undecimus://"] ||
            [s hasPrefix:@"filza://"]) {
            return NO;
        }
    }
    return orig_canOpenURL ? orig_canOpenURL(self, _cmd, url) : NO;
}

static void zk_swizzle_class_method(Class cls, SEL sel, IMP newImp, IMP *origOut)
{
    if (!cls || !sel) return;
    Method m = class_getClassMethod(cls, sel);
    if (!m) return;
    if (origOut) *origOut = method_setImplementation(m, newImp);
}

static void zk_swizzle_instance_method(Class cls, SEL sel, IMP newImp, IMP *origOut)
{
    if (!cls || !sel) return;
    Method m = class_getInstanceMethod(cls, sel);
    if (!m) return;
    if (origOut) *origOut = method_setImplementation(m, newImp);
}

/* ============================================================
   调试检测:ptrace 直接掐掉
   —— 全局 patch 是安全的,正常 App 根本不会自己 ptrace 自己。
   ============================================================ */

static void zk_kill_ptrace(void)
{
    void *p = dlsym(RTLD_DEFAULT, "ptrace");
    if (!p) return;
    if (zk_patch_return_false(p)) {
        ZKLOG(@"防封:ptrace 已封");
    }
}

/* ============================================================
   安装(尽早)
   ============================================================ */

static bool g_earlyInstalled = false;

bool zk_antiban_install_early(void)
{
    if (g_earlyInstalled) return true;
    g_earlyInstalled = true;

    zk_kill_ptrace();

    /* NSFileManager 的文件探测 */
    Class fm = objc_getClass("NSFileManager");
    if (fm) {
        zk_swizzle_class_method(fm, @selector(fileExistsAtPath:),
                                (IMP)zk_fileExists, (IMP *)&orig_fileExists);
        zk_swizzle_class_method(fm, @selector(fileExistsAtPath:isDirectory:),
                                (IMP)zk_fileExistsIsDir, (IMP *)&orig_fileExistsIsDir);
    }

    /* cydia:// 这类 scheme 探测 */
    Class app = objc_getClass("UIApplication");
    if (app) {
        zk_swizzle_instance_method(app, @selector(canOpenURL:),
                                   (IMP)zk_canOpenURL, (IMP *)&orig_canOpenURL);
    }

    ZKLOG(@"防封:环境检测处理完毕");
    return true;
}

/* ============================================================
   游戏自带反作弊:扫描 + 打补丁
   ============================================================ */

static NSMutableArray *g_patchedDesc  = nil;   /* 描述文字 */
static NSMutableArray *g_patchedMeth  = nil;   /* NSValue 包 MethodInfo* */

static BOOL zk_name_hits(const char *name, const char *const *hints)
{
    if (!name) return NO;
    for (int i = 0; hints[i]; i++) {
        if (strstr(name, hints[i]) != NULL) return YES;
    }
    return NO;
}

/* 类名:只挑跟反作弊/检测强相关的,别乱抓 */
static const char *kClassHints[] = {
    "AntiCheat", "AntiHack", "CheatDetect", "CheatCheck", "CheatReport",
    "SecurityCheck", "SecurityService", "SecurityManager",
    "IntegrityCheck", "IntegrityVerify", "DataVerify", "DataValidation",
    "RiskControl", "RiskManager", "GuardService", "EnforceService",
    "PunishManager", "BanManager", "DetectManager", "DetectService",
    "MonitorManager", "AuditManager", "CheatManager", "Cheat",
    NULL
};

/* 方法名:只掐"判断/上报"类,不碰 Update / Start 这种生命周期 */
static const char *kMethodHints[] = {
    "Check", "Detect", "Verify", "Validate", "Inspect", "Audit",
    "IsCheat", "IsHack", "IsBan", "Ban", "Kick", "Punish", "Report",
    "Enforce", "Watch", "Monitor", "Confirm", "Submit",
    NULL
};

static const char *kMethodSkip[] = {
    "Update", "LateUpdate", "FixedUpdate", "Start", "Awake", "OnEnable",
    "OnDisable", "OnDestroy", "get_", "set_", "ToString", "Equals", "GetHashCode",
    NULL
};

void zk_antiban_scan_unity(void)
{
    if (!zk_rt_ready()) return;

    if (!g_patchedDesc) g_patchedDesc = [NSMutableArray array];
    if (!g_patchedMeth) g_patchedMeth = [NSMutableArray array];

    int total = zk_rt_class_count();
    int patched = 0;

    for (int i = 0; i < total; i++) {
        Il2CppClass *k = zk_rt_class_at(i);
        const char *cn = zk_rt_class_name(k);
        if (!cn) continue;

        const char *ns = zk_rt_class_ns(k);
        if (ns && (strstr(ns, "UnityEngine") || strstr(ns, "System") ||
                   strstr(ns, "Unity.") || strstr(ns, "TMPro"))) continue;

        if (!zk_name_hits(cn, kClassHints)) continue;

        void *iter = NULL;
        MethodInfo *m = NULL;
        while ((m = zk_rt_method_first(k, &iter)) != NULL) {
            const char *mn = zk_rt_method_name(m);
            if (!mn) continue;
            if (zk_name_hits(mn, kMethodSkip)) continue;
            if (!zk_name_hits(mn, kMethodHints)) continue;

            int argc = zk_rt_method_argc(m);
            if (argc < 0 || argc > 3) continue;
            if (!zk_rt_method_ptr(m)) continue;

            const char *rt = zk_rt_method_ret(m);
            ZKRetKind kind = ZK_RET_FALSE;

            if (rt) {
                if (strcmp(rt, "System.Void") == 0)          kind = ZK_RET_VOID;
                else if (strcmp(rt, "System.Boolean") == 0)  kind = ZK_RET_FALSE;
                else if (strcmp(rt, "System.Int32") == 0)    kind = ZK_RET_ZERO_INT;
                else continue;   /* 别的返回类型不碰,免得把逻辑弄坏 */
            }

            if (zk_rt_method_patched(m)) continue;
            if (!zk_rt_patch_method(m, kind)) continue;

            [g_patchedMeth addObject:[NSValue valueWithPointer:m]];
            [g_patchedDesc addObject:[NSString stringWithFormat:@"  %s.%s::%s (argc=%d)",
                                      ns && ns[0] ? ns : "-", cn, mn, argc]];
            patched++;

            if (patched >= 120) break;
        }

        if (patched >= 120) break;
    }

    ZKLOG(@"防封:拦掉 %d 处检测逻辑", patched);
}

void zk_antiban_unpatch_unity(void)
{
    if (!g_patchedMeth) return;

    for (NSValue *v in g_patchedMeth) {
        MethodInfo *m = (MethodInfo *)[v pointerValue];
        if (m) zk_rt_unpatch_method(m);
    }
    [g_patchedMeth removeAllObjects];
    [g_patchedDesc removeAllObjects];
}

int zk_antiban_patched_count(void)
{
    return zk_rt_patch_count();
}

NSString *zk_antiban_report(void)
{
    NSMutableString *s = [NSMutableString string];

    [s appendString:@"环境检测封堵: 调试检测(ptrace) / 越狱路径探测 / 可疑 URL scheme\n"];
    [s appendString:@"未处理(做不到,别信任何说能做的): 服务端行为风控、系统级调用拦截\n"];

    if (g_patchedDesc.count) {
        [s appendFormat:@"已拦游戏内检测 %lu 处:\n", (unsigned long)g_patchedDesc.count];
        for (NSString *l in g_patchedDesc) [s appendFormat:@"%@\n", l];
    } else {
        [s appendString:@"游戏内检测: 还没扫到(Unity 起来后自动扫,或该类名跟预期不同)\n"];
    }

    return s;
}
