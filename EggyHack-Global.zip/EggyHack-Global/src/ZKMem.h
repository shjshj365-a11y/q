//
//  ZKMem.h
//  内存读写 / ARM64 指令补丁 / 镜像查询
//
//  全部零依赖,只用系统 API(dlopen / mach_vm / sys_icache_invalidate)。
//

#ifndef ZK_MEM_H
#define ZK_MEM_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---------- 镜像 ---------- */

/// 遍历已加载镜像,路径里包含 imgName 的那个,返回加载基址(slide 已算好)。
uintptr_t zk_image_base(const char *imgName);
/// 返回完整路径。
const char *zk_image_path(const char *imgName);
/// 主可执行文件的基址(游戏主二进制,不是 UnityFramework)。
uintptr_t zk_main_base(void);

/* ---------- 读写 ---------- */

/// 把目标页改成可读写(必要时走 VM_PROT 重映射),返回是否成功。
bool zk_make_writable(void *addr, size_t len);

bool zk_mem_write(void *addr, const void *data, size_t len);
bool zk_mem_read(const void *addr, void *out, size_t len);

/// 安全读取:地址非法时返回 false,不崩。
bool zk_safe_read(const void *addr, void *out, size_t len);
/// 判断指针看着像不像一个有效的 IL2CPP 对象(头 8 字节是个已加载的指针)。
bool zk_looks_like_obj(const void *p);

/* ---------- 代码补丁 ---------- */

bool zk_patch_insn(void *addr, uint32_t insn);
bool zk_patch_bytes(void *addr, const void *bytes, size_t len);
bool zk_patch_nop(void *addr, int count);
bool zk_patch_ret(void *addr);
bool zk_patch_return_false(void *addr);
bool zk_patch_return_true(void *addr);

/// 备份地址处 8 字节(供还原用)。
bool zk_patch_save(void *addr, uint8_t out[8]);
/// 还原备份的字节。
bool zk_patch_restore(void *addr, const uint8_t saved[8]);

/* ---------- ARM64 常量 ---------- */

#define ZK_ARM64_NOP            0xD503201Fu
#define ZK_ARM64_RET            0xD65F03C0u
#define ZK_ARM64_MOV_W0_0       0x52800000u
#define ZK_ARM64_MOV_W0_1       0x52800020u

uint32_t zk_arm64_movz_w(uint8_t rd, uint16_t imm, uint8_t shift);
uint32_t zk_arm64_mov_w0(uint16_t imm);

#ifdef __cplusplus
}
#endif

#endif /* ZK_MEM_H */
