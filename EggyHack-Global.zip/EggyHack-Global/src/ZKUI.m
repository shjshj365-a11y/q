//
//  ZKUI.m
//

#import "ZKUI.h"

UIWindowScene *zk_active_window_scene(void)
{
    if (@available(iOS 13.0, *)) {
        UIWindowScene *fallback = nil;
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
            if (![s isKindOfClass:[UIWindowScene class]]) continue;
            UIWindowScene *ws = (UIWindowScene *)s;
            if (ws.activationState == UISceneActivationStateForegroundActive) return ws;
            if (!fallback) fallback = ws;
        }
        return fallback;
    }
    return nil;
}

UIWindow *zk_make_overlay_window(CGFloat levelOffset)
{
    UIWindow *w = nil;

    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene = zk_active_window_scene();
        if (scene) w = [[UIWindow alloc] initWithWindowScene:scene];
    }
    if (!w) w = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];

    w.backgroundColor = [UIColor clearColor];
    w.windowLevel = UIWindowLevelAlert + levelOffset;
    w.rootViewController = [[UIViewController alloc] init];
    w.rootViewController.view.backgroundColor = [UIColor clearColor];
    w.hidden = NO;

    return w;
}
