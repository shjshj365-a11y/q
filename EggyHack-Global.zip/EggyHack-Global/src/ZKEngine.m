//
//  ZKEngine.m
//

#import "ZKEngine.h"
#import "ZKIL2CPP.h"
#import "ZKMem.h"
#import "ZKConfig.h"
#import "ZKAntiBan.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>
#import <string.h>
#import <stdio.h>

/* ============================================================
   一个小容器:记住某个字段的原值,方便还原
   ============================================================ */

@interface ZKSlot : NSObject
@property (nonatomic, assign) void      *obj;        /* 0 表示静态字段 */
@property (nonatomic, assign) FieldInfo *field;
@property (nonatomic, assign) float      original;
@property (nonatomic, assign) BOOL       applied;
@property (nonatomic, copy)   NSString  *desc;
@end

@implementation ZKSlot
@end

/* ============================================================
   工具
   ============================================================ */

static BOOL zk_has(const char *hay, const char *needle)
{
    if (!hay || !needle) return NO;
    return strstr(hay, needle) != NULL;
}

static BOOL zk_has_nocase(const char *hay, const char *needle)
{
    if (!hay || !needle) return NO;

    size_t hn = strlen(hay), nn = strlen(needle);
    if (nn == 0 || hn < nn) return NO;

    for (size_t i = 0; i + nn <= hn; i++) {
        size_t j = 0;
        for (; j < nn; j++) {
            char a = hay[i + j], b = needle[j];
            if (a >= 'A' && a <= 'Z') a += 32;
            if (b >= 'A' && b <= 'Z') b += 32;
            if (a != b) break;
        }
        if (j == nn) return YES;
    }
    return NO;
}

/// 按命名空间 + 简单名找类(不依赖 assembly 名字,版本差异太大)。
static Il2CppClass *zk_find_ns(const char *ns, const char *name)
{
    int n = zk_rt_class_count();
    for (int i = 0; i < n; i++) {
        Il2CppClass *k = zk_rt_class_at(i);
        const char *cn = zk_rt_class_name(k);
        if (!cn || strcmp(cn, name) != 0) continue;
        if (ns) {
            const char *kns = zk_rt_class_ns(k);
            if (!kns || strcmp(kns, ns) != 0) continue;
        }
        return k;
    }
    return NULL;
}

static const char *kUnityNS = "UnityEngine";

/* ============================================================
   ZKEngine
   ============================================================ */

@interface ZKEngine ()
@property (nonatomic, assign) BOOL scanDone;
@property (nonatomic, assign) BOOL localPlayerFound;
@property (nonatomic, assign) BOOL cameraFound;
@property (nonatomic, assign) int  entityCount;
@property (nonatomic, assign) int  espCount;
@property (nonatomic, assign) BOOL speedBound;
@property (nonatomic, assign) BOOL noclipBound;
@property (nonatomic, assign) BOOL cooldownBound;
@property (nonatomic, assign) int  antiCheatPatched;
@property (nonatomic, assign) BOOL antiBanOn;
@end

@implementation ZKEngine
{
    Il2CppClass *_playerClass;
    Il2CppClass *_cameraClass;
    MethodInfo  *_mFindObjects;      /* UnityEngine.Object.FindObjectsOfType(Type) */
    MethodInfo  *_mFindAll;          /* UnityEngine.Resources.FindObjectsOfTypeAll(Type) */
    MethodInfo  *_mW2S;              /* Camera.WorldToScreenPoint(Vector3) */
    MethodInfo  *_mCamMain;          /* Camera.get_main() */
    void        *_camera;

    FieldInfo   *_fLocalFlag;        /* isMine / isLocalPlayer 之类的 bool */
    FieldInfo   *_fTeam;             /* 队伍 / 阵营 */

    void        *_localPlayer;
    NSString    *_localMode;         /* 本地玩家怎么认出来的 */

    NSMutableArray<ZKSlot *> *_speedSlots;
    NSMutableArray<ZKSlot *> *_cooldownSlots;
    NSMutableArray<NSValue *> *_cachedMethods;   /* 冷却相关被 patch 的方法 */

    void        *_noclipCollider;
    void        *_noclipCC;
    void        *_noclipRigid;
    BOOL         _noclipApplied;

    NSMutableArray *_entityCache;
    NSTimeInterval _entityStamp;

    CADisplayLink *_link;
    NSTimeInterval _lastLogicTick;
    NSTimeInterval _lastFlyTick;

    float         _flyY;
    BOOL          _flyYValid;

    NSMutableArray<NSString *> *_log;        /* 扫描过程记录,导出报告用 */
    NSMutableArray<NSString *> *_missing;    /* 没绑上的功能 */
    NSMutableArray<NSString *> *_candidates; /* 玩家类候选,报告里给开发者看 */
}

+ (instancetype)shared
{
    static ZKEngine *inst = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ inst = [[ZKEngine alloc] init]; });
    return inst;
}

- (instancetype)init
{
    self = [super init];
    if (!self) return nil;

    _speedSlots     = [NSMutableArray array];
    _cooldownSlots  = [NSMutableArray array];
    _cachedMethods  = [NSMutableArray array];
    _log            = [NSMutableArray array];
    _missing        = [NSMutableArray array];
    _candidates     = [NSMutableArray array];

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    _speedMul   = [d objectForKey:@"zk_speed"] ? [d floatForKey:@"zk_speed"] : ZK_SPEED_DEFAULT;
    _flySpeed   = [d objectForKey:@"zk_fly"]   ? [d floatForKey:@"zk_fly"]   : ZK_FLY_DEFAULT;
    _speedMul   = MAX(ZK_SPEED_MIN, MIN(ZK_SPEED_MAX, _speedMul));
    _flySpeed   = MAX(ZK_FLY_MIN,   MIN(ZK_FLY_MAX,   _flySpeed));
    _flyMode    = 0;

    _antiBanOn  = [d objectForKey:@"zk_antiban"] ? [d boolForKey:@"zk_antiban"] : (ZK_DEF_ANTIBAN != 0);
    _markLocalOn = NO;
    _espOn = NO; _flyOn = NO; _noclipOn = NO; _speedOn = NO; _cooldownOn = NO;

    return self;
}

/* ============================================================
   启动
   ============================================================ */

- (void)bootstrap
{
    /* 先等 Unity 起来:每 0.5 秒探一次,最多 60 次 */
    __block int tries = 0;
    __block void (^waitBlock)(void);
    __weak typeof(self) weakSelf = self;

    waitBlock = ^{
        __strong typeof(self) self_ = weakSelf;
        if (!self_) return;

        tries++;
        if (zk_rt_init() && zk_rt_ready()) {
            ZKLOG(@"Unity 就绪,开始扫描");
            [self_ scan];
            [self_ startDriver];

            if (self_.antiBanOn) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{
                    zk_antiban_scan_unity();
                    self_.antiCheatPatched = zk_antiban_patched_count();
                });
            }
            return;
        }

        if (tries > 60) {
            [self_->_missing addObject:@"Unity 30 秒内没就绪(包可能没脱壳 / 没注入成功)"];
            ZKLOG(@"等 Unity 超时");
            return;
        }

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), waitBlock);
    };

    ZKLOG(@"EggyHack 加载 pid=%d", getpid());
    zk_antiban_install_early();

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(ZK_START_DELAY * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), waitBlock);
}

/* ============================================================
   扫描
   ============================================================ */

- (void)scan
{
    [_log addObject:[NSString stringWithFormat:@"IL2CPP 就绪,类表 %d 个类", zk_rt_class_count()]];

    [self scanCamera];
    [self scanPlayerClass];
    [self scanLocalPlayer];
    [self scanSpeedFields];
    [self scanCooldownFields];

    self.scanDone = YES;
    ZKLOG(@"扫描结束:玩家类=%@ 相机=%@", _playerClass ? @(zk_rt_class_name(_playerClass)) : @"nil",
          _camera ? @"有" : @"无");
}

- (void)scanCamera
{
    Il2CppClass *cam = zk_find_ns(kUnityNS, "Camera");
    if (!cam) {
        [_missing addObject:@"相机类没找到(UnityEngine.Camera)"];
        return;
    }

    _cameraClass = cam;
    _mCamMain = zk_rt_class_method(cam, "get_main", 0);
    _mW2S     = zk_rt_class_method(cam, "WorldToScreenPoint", 1);

    if (!_mW2S) {
        /* 部分版本导出成带 _Injected 后缀 */
        _mW2S = zk_rt_class_method(cam, "WorldToScreenPoint_Injected", 2);
        if (_mW2S) [_log addObject:@"相机投影:用 Injected 版本"];
    }

    [self refreshCamera];
}

- (void)refreshCamera
{
    if (_camera && zk_looks_like_obj(_camera)) return;

    _camera = NULL;
    if (_mCamMain) {
        _camera = zk_rt_invoke(_mCamMain, NULL, NULL);
    }

    if (!_camera) {
        /* 退路:Camera.allCameras 取第一个 */
        MethodInfo *mAll = zk_rt_class_method(_cameraClass, "get_allCameras", 0);
        if (mAll) {
            void *arr = zk_rt_invoke(mAll, NULL, NULL);
            if (arr && zk_rt_array_len(arr) > 0) _camera = zk_rt_array_at(arr, 0);
        }
    }

    self.cameraFound = (_camera != NULL);
    if (!_camera) [_missing addObject:@"没拿到相机实例(透视会没框)"];
}

/* ---------- 玩家类 ---------- */

- (int)scorePlayerClass:(Il2CppClass *)k name:(const char *)name
{
    int score = 0;
    const char *ns = zk_rt_class_ns(k);

    /* 命名空间先筛一遍 */
    if (ns && (zk_has(ns, "UnityEngine") || zk_has(ns, "System") || zk_has(ns, "Unity."))) return -1000;

    if (zk_has_nocase(name, "LocalPlayer"))         score += 60;
    else if (zk_has_nocase(name, "PlayerController")) score += 55;
    else if (zk_has_nocase(name, "PlayerEntity"))     score += 55;
    else if (zk_has_nocase(name, "PlayerActor"))      score += 50;
    else if (zk_has_nocase(name, "GamePlayer"))       score += 50;
    else if (zk_has_nocase(name, "PlayerObject"))     score += 50;
    else if (zk_has_nocase(name, "EggyPlayer"))       score += 50;
    else if (zk_has_nocase(name, "Player"))           score += 35;
    else if (zk_has_nocase(name, "Role"))             score += 25;
    else if (zk_has_nocase(name, "Character"))        score += 20;
    else if (zk_has_nocase(name, "Unit"))             score += 15;
    else return -1000;

    if (zk_has_nocase(name, "Manager") || zk_has_nocase(name, "System") ||
        zk_has_nocase(name, "Data")    || zk_has_nocase(name, "Info")   ||
        zk_has_nocase(name, "UI")      || zk_has_nocase(name, "Config") ||
        zk_has_nocase(name, "View")    || zk_has_nocase(name, "Panel")) score -= 45;

    /* 看字段:有速度/是否本人/队伍 → 大概率就是它 */
    void *iter = NULL;
    FieldInfo *f = NULL;
    int nFields = 0;
    while ((f = zk_rt_field_first(k, &iter)) != NULL) {
        const char *fn = zk_rt_field_name(f);
        const char *ft = zk_rt_field_type(f);
        nFields++;
        if (nFields > 400) break;

        if (zk_has_nocase(fn, "speed")) score += 12;
        if (zk_has_nocase(fn, "islocal") || zk_has_nocase(fn, "ismine") ||
            zk_has_nocase(fn, "isowner")) score += 20;
        if (zk_has_nocase(fn, "team") || zk_has_nocase(fn, "camp")) score += 10;
        (void)ft;
    }

    if (nFields == 0) score -= 30;

    return score;
}

- (void)scanPlayerClass
{
    int n = zk_rt_class_count();

    NSMutableArray *scored = [NSMutableArray array];   /* @[ @(score), [NSValue valueWithPointer:k] ] */
    for (int i = 0; i < n; i++) {
        Il2CppClass *k = zk_rt_class_at(i);
        const char *cn = zk_rt_class_name(k);
        if (!cn) continue;
        int s = [self scorePlayerClass:k name:cn];
        if (s > 25) {
            [scored addObject:@[ @(s), [NSValue valueWithPointer:k] ]];
        }
    }

    [scored sortUsingComparator:^NSComparisonResult(NSArray *a, NSArray *b) {
        return [b[0] compare:a[0]];
    }];

    /* 报告里留一份候选清单,自动认不出来时靠它手工填 */
    for (int i = 0; i < (int)scored.count && i < 15; i++) {
        Il2CppClass *k = (Il2CppClass *)[scored[i][1] pointerValue];
        [_candidates addObject:[NSString stringWithFormat:@"  [%d] %s.%s  (assembly %s)",
                                [scored[i][0] intValue],
                                zk_rt_class_ns(k), zk_rt_class_name(k), zk_rt_class_image(k)]];
    }

    [self resolveFindObjects];

    /* 从高分往低试,谁能在场上真的找出实例,就是它 */
    for (int i = 0; i < (int)scored.count && i < 8; i++) {
        Il2CppClass *k = (Il2CppClass *)[scored[i][1] pointerValue];
        int cnt = [self countInstancesOf:k];
        if (cnt > 0) {
            _playerClass = k;
            [_log addObject:[NSString stringWithFormat:@"玩家类 = %s.%s(%s),场上当前 %d 个",
                             zk_rt_class_ns(k), zk_rt_class_name(k), zk_rt_class_image(k), cnt]];
            break;
        }
    }

    if (!_playerClass) {
        [_missing addObject:@"玩家类没认出来(见报告里的候选清单)"];
        return;
    }

    /* 找出 isMine / team 这类字段 */
    void *iter = NULL;
    FieldInfo *f = NULL;
    while ((f = zk_rt_field_first(_playerClass, &iter)) != NULL) {
        const char *fn = zk_rt_field_name(f);
        const char *ft = zk_rt_field_type(f);
        if (!fn || !ft) continue;

        if (strcmp(ft, "System.Boolean") == 0 && !_fLocalFlag) {
            if (zk_has_nocase(fn, "islocal") || zk_has_nocase(fn, "ismine") ||
                zk_has_nocase(fn, "isowner") || zk_has_nocase(fn, "ismy") ||
                zk_has_nocase(fn, "isself")  || zk_has_nocase(fn, "isplayer")) {
                _fLocalFlag = f;
            }
        }
        if (strcmp(ft, "System.Int32") == 0 && !_fTeam) {
            if (zk_has_nocase(fn, "team") || zk_has_nocase(fn, "camp") || zk_has_nocase(fn, "group")) {
                _fTeam = f;
            }
        }
    }
}

- (void)resolveFindObjects
{
    Il2CppClass *objCls = zk_find_ns(kUnityNS, "Object");
    if (objCls) {
        _mFindObjects = zk_rt_class_method(objCls, "FindObjectsOfType", 1);
        if (!_mFindObjects) _mFindObjects = zk_rt_class_method(objCls, "FindObjectsByType", 1);
    }

    Il2CppClass *res = zk_find_ns(kUnityNS, "Resources");
    if (res) {
        _mFindAll = zk_rt_class_method(res, "FindObjectsOfTypeAll", 1);
        if (!_mFindAll) _mFindAll = zk_rt_class_method(res, "FindObjectsOfTypeAll", -1);
    }
}

- (NSArray *)instancesOf:(Il2CppClass *)k
{
    if (!k) return @[];

    void *typeObj = zk_rt_type_obj(k);
    if (!typeObj) return @[];

    void *args[1] = { typeObj };
    void *arr = NULL;

    if (_mFindObjects) arr = zk_rt_invoke(_mFindObjects, NULL, args);
    if ((!arr || zk_rt_array_len(arr) == 0) && _mFindAll) arr = zk_rt_invoke(_mFindAll, NULL, args);
    if (!arr) return @[];

    int len = zk_rt_array_len(arr);
    if (len <= 0) return @[];

    NSMutableArray *out = [NSMutableArray arrayWithCapacity:len];
    for (int i = 0; i < len; i++) {
        void *o = zk_rt_array_at(arr, i);
        if (o) [out addObject:[NSValue valueWithPointer:o]];
    }
    return out;
}

- (int)countInstancesOf:(Il2CppClass *)k
{
    return (int)[self instancesOf:k].count;
}

/* ---------- 本地玩家 ---------- */

- (void)scanLocalPlayer
{
    if (!_playerClass) return;

    /* 1) 静态字段:localPlayer / mainPlayer / myPlayer 之类 */
    static const char *staticHints[] = {
        "localPlayer", "LocalPlayer", "m_LocalPlayer", "mainPlayer", "MainPlayer",
        "myPlayer", "MyPlayer", "selfPlayer", "SelfPlayer", "localRole", "LocalRole",
        "localCharacter", "mainCharacter", "localActor", "LocalActor", "self", NULL
    };

    Il2CppClass *cur = _playerClass;
    int guard = 0;
    while (cur && guard++ < 4) {
        void *iter = NULL;
        FieldInfo *f = NULL;
        while ((f = zk_rt_field_first(cur, &iter)) != NULL) {
            if (!zk_rt_field_is_static(f)) continue;
            const char *fn = zk_rt_field_name(f);
            if (!fn) continue;

            for (int i = 0; staticHints[i]; i++) {
                if (strcmp(fn, staticHints[i]) != 0) continue;

                void *v = NULL;
                if (zk_rt_field_static_get(f, &v) && zk_looks_like_obj(v)) {
                    _localPlayer = v;
                    _localMode = [NSString stringWithFormat:@"静态字段 %s", fn];
                    self.localPlayerFound = YES;
                    [_log addObject:[NSString stringWithFormat:@"本地玩家:静态字段 %s", fn]];
                    return;
                }
            }
        }
        cur = zk_rt_class_parent(cur);
    }

    /* 2) 实例上的 isMine / isLocalPlayer */
    if (_fLocalFlag) {
        for (NSValue *v in [self entities]) {
            void *o = [v pointerValue];
            if (zk_rt_field_get_bool(o, _fLocalFlag)) {
                _localPlayer = o;
                _localMode = [NSString stringWithFormat:@"字段 %s", zk_rt_field_name(_fLocalFlag)];
                self.localPlayerFound = YES;
                [_log addObject:[NSString stringWithFormat:@"本地玩家:字段 %s = true",
                                 zk_rt_field_name(_fLocalFlag)]];
                return;
            }
        }
    }

    /* 3) 退路:离相机最近的那个 */
    [self refreshCamera];
    if (_camera) {
        ZKVec3 cp = zk_rt_get_pos(_camera);
        float best = 1e9f;
        void *bestObj = NULL;
        for (NSValue *v in [self entities]) {
            void *o = [v pointerValue];
            ZKVec3 p = zk_rt_get_pos(o);
            float d = (p.x - cp.x) * (p.x - cp.x) + (p.y - cp.y) * (p.y - cp.y) + (p.z - cp.z) * (p.z - cp.z);
            if (d < best) { best = d; bestObj = o; }
        }
        if (bestObj) {
            _localPlayer = bestObj;
            _localMode = @"按『离相机最近』推断(可能认错,用悬浮窗里的『高亮本地玩家』核对)";
            self.localPlayerFound = YES;
            [_log addObject:@"本地玩家:按最近距离推断"];
            return;
        }
    }

    [_missing addObject:@"本地玩家没认出来(飞天/遁地会不起作用)"];
}

/* ---------- 移速 / 冷却字段 ---------- */

- (void)collectFloatSlots:(NSMutableArray<ZKSlot *> *)slots
                  fromObj:(void *)obj
                    hints:(NSArray<NSString *> *)hints
                   prefix:(NSString *)prefix
{
    if (!obj) return;

    Il2CppClass *k = zk_rt_obj_class(obj);
    int guard = 0;
    while (k && guard++ < 6) {
        void *iter = NULL;
        FieldInfo *f = NULL;
        while ((f = zk_rt_field_first(k, &iter)) != NULL) {
            const char *fn = zk_rt_field_name(f);
            const char *ft = zk_rt_field_type(f);
            if (!fn || !ft) continue;
            if (strcmp(ft, "System.Single") != 0) continue;
            if (zk_rt_field_is_static(f)) continue;

            BOOL hit = NO;
            for (NSString *h in hints) {
                if (zk_has_nocase(fn, h.UTF8String)) { hit = YES; break; }
            }
            if (!hit) continue;

            ZKSlot *s = [[ZKSlot alloc] init];
            s.obj      = obj;
            s.field    = f;
            s.original = zk_rt_field_get_float(obj, f);
            s.desc     = [NSString stringWithFormat:@"%@.%s.%s = %.2f",
                          prefix, zk_rt_class_name(k), fn, s.original];
            if (s.original <= 0.0001f) continue;      /* 原值是 0 的一律不碰 */
            [slots addObject:s];
        }
        k = zk_rt_class_parent(k);
    }
}

- (void)scanSpeedFields
{
    if (!_playerClass) return;
    if (!_localPlayer) {
        /* 拿不到本地玩家就先用场上第一个当参考 */
        NSArray *all = [self entities];
        if (all.count) _localPlayer = [all[0] pointerValue];
    }

    NSArray *hints = @[ @"speed", @"Speed", @"velocityScale", @"moveRate" ];

    [_speedSlots removeAllObjects];
    [self collectFloatSlots:_speedSlots fromObj:_localPlayer hints:hints prefix:@"本体"];

    /* 移动组件:PlayerMove / Movement / Locomotion 这些,挨个 GetComponent 试 */
    static const char *moveHints[] = {
        "PlayerMove", "MoveComponent", "Movement", "Locomotion", "Motor",
        "CharacterMove", "MoveController", "ActorMove", "UnitMove", "PlayerMotion", NULL
    };

    int n = zk_rt_class_count();
    for (int i = 0; i < n; i++) {
        Il2CppClass *k = zk_rt_class_at(i);
        const char *cn = zk_rt_class_name(k);
        if (!cn) continue;

        BOOL hit = NO;
        for (int j = 0; moveHints[j]; j++) {
            if (zk_has_nocase(cn, moveHints[j])) { hit = YES; break; }
        }
        if (!hit) continue;

        const char *kns = zk_rt_class_ns(k);
        if (kns && (zk_has(kns, "UnityEngine") || zk_has(kns, "System"))) continue;

        void *comp = [self getComponent:k on:_localPlayer];
        if (!comp) continue;

        [self collectFloatSlots:_speedSlots fromObj:comp hints:hints
                         prefix:[NSString stringWithFormat:@"组件 %s", cn]];
    }

    self.speedBound = (_speedSlots.count > 0);
    if (!self.speedBound) [_missing addObject:@"移速字段没找到(加速会无效)"];
    else [_log addObject:[NSString stringWithFormat:@"移速字段 %lu 个", (unsigned long)_speedSlots.count]];
}

- (void)scanCooldownFields
{
    if (!_localPlayer) return;

    NSArray *hints = @[ @"cooldown", @"coolDown", @"CoolDown", @"cd", @"CD" ];

    [_cooldownSlots removeAllObjects];
    [self collectFloatSlots:_cooldownSlots fromObj:_localPlayer hints:hints prefix:@"本体"];

    static const char *skillHints[] = {
        "Skill", "Ability", "Weapon", "Buff", "Prop", "Item", "Spell", NULL
    };

    int n = zk_rt_class_count();
    for (int i = 0; i < n; i++) {
        Il2CppClass *k = zk_rt_class_at(i);
        const char *cn = zk_rt_class_name(k);
        if (!cn) continue;

        BOOL hit = NO;
        for (int j = 0; skillHints[j]; j++) {
            if (zk_has_nocase(cn, skillHints[j])) { hit = YES; break; }
        }
        if (!hit) continue;

        const char *kns = zk_rt_class_ns(k);
        if (kns && (zk_has(kns, "UnityEngine") || zk_has(kns, "System"))) continue;

        void *comp = [self getComponent:k on:_localPlayer];
        if (!comp) continue;

        [self collectFloatSlots:_cooldownSlots fromObj:comp hints:hints
                         prefix:[NSString stringWithFormat:@"组件 %s", cn]];
    }

    self.cooldownBound = (_cooldownSlots.count > 0);
    if (!self.cooldownBound) [_missing addObject:@"冷却字段没找到(无冷却会无效)"];
}

/* ---------- 组件获取 ---------- */

- (void *)getComponent:(Il2CppClass *)compClass on:(void *)obj
{
    if (!compClass || !obj) return NULL;

    void *typeObj = zk_rt_type_obj(compClass);
    if (!typeObj) return NULL;

    void *args[1] = { typeObj };
    void *comp = zk_rt_invoke_on(obj, "GetComponent", 1, args);
    if (!comp || !zk_looks_like_obj(comp)) return NULL;
    return comp;
}

/* ============================================================
   驱动
   ============================================================ */

- (void)startDriver
{
    if (_link) return;

    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick)];
    _link.preferredFramesPerSecond = 30;
    [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

    ZKLOG(@"驱动已启动");
}

- (void)tick
{
    if (!zk_rt_ready()) return;

    NSTimeInterval now = CACurrentMediaTime();

    /* 逻辑 10Hz 就够,别给游戏线程添负担 */
    if (now - _lastLogicTick >= 0.1) {
        _lastLogicTick = now;

        if (!self.localPlayerFound) [self scanLocalPlayer];
        if (!_camera) [self refreshCamera];

        [self applySpeed];
        [self applyCooldown];
        [self applyNoclip];
        [self applyFly:now];

        self.entityCount = (int)[self entities].count;
    }
}

/* ---------- 加速 ---------- */

- (void)applySpeed
{
    if (!_speedSlots.count) return;

    if (!self.speedOn) {
        if (!self.speedBound) return;
        for (ZKSlot *s in _speedSlots) {
            if (!s.applied) continue;
            zk_rt_field_set_float(s.obj, s.field, s.original);
            s.applied = NO;
        }
        return;
    }

    float mul = MAX(ZK_SPEED_MIN, MIN(ZK_SPEED_MAX, _speedMul));

    for (ZKSlot *s in _speedSlots) {
        float want = s.original * mul;
        if (want > 5000.0f) want = 5000.0f;      /* 别写出离谱值 */
        float cur = zk_rt_field_get_float(s.obj, s.field);
        if (fabsf(cur - want) > 0.01f) {
            zk_rt_field_set_float(s.obj, s.field, want);
            s.applied = YES;
        }
    }
}

/* ---------- 无冷却 ---------- */

- (void)applyCooldown
{
    if (!self.cooldownOn) {
        for (ZKSlot *s in _cooldownSlots) {
            if (!s.applied) continue;
            zk_rt_field_set_float(s.obj, s.field, s.original);
            s.applied = NO;
        }
        return;
    }

    for (ZKSlot *s in _cooldownSlots) {
        if (zk_rt_field_get_float(s.obj, s.field) > 0.0f) {
            zk_rt_field_set_float(s.obj, s.field, 0.0f);
            s.applied = YES;
        }
    }
}

/* ---------- 遁地 / 穿墙 ---------- */

- (void)resolveNoclipTargets
{
    if (_noclipCollider || !_localPlayer) return;

    Il2CppClass *collider = zk_find_ns(kUnityNS, "Collider");
    if (collider) _noclipCollider = [self getComponent:collider on:_localPlayer];

    Il2CppClass *cc = zk_find_ns(kUnityNS, "CharacterController");
    if (cc) _noclipCC = [self getComponent:cc on:_localPlayer];

    Il2CppClass *rb = zk_find_ns(kUnityNS, "Rigidbody");
    if (rb) _noclipRigid = [self getComponent:rb on:_localPlayer];

    self.noclipBound = (_noclipCollider != NULL || _noclipCC != NULL || _noclipRigid != NULL);
    if (self.noclipBound) [_log addObject:@"遁地:已拿到碰撞体组件"];
    else [_missing addObject:@"遁地:没拿到碰撞体组件"];
}

static void zk_invoke_set_enabled(void *obj, BOOL enabled)
{
    if (!obj) return;
    MethodInfo *m = zk_rt_obj_method(obj, "set_enabled", 1);
    if (!m) m = zk_rt_obj_method(obj, "set_enable", 1);
    if (!m) return;

    uint8_t v = enabled ? 1 : 0;
    void *args[1] = { &v };
    zk_rt_invoke(m, obj, args);
}

- (void)applyNoclip
{
    if (self.noclipOn) [self resolveNoclipTargets];

    if (!self.noclipOn) {
        if (!_noclipApplied) return;
        zk_invoke_set_enabled(_noclipCollider, YES);
        zk_invoke_set_enabled(_noclipCC, YES);
        _noclipApplied = NO;
        return;
    }

    zk_invoke_set_enabled(_noclipCollider, NO);
    zk_invoke_set_enabled(_noclipCC, NO);

    if (_noclipRigid) {
        MethodInfo *m = zk_rt_obj_method(_noclipRigid, "set_useGravity", 1);
        if (m) {
            uint8_t v = 0;
            void *args[1] = { &v };
            zk_rt_invoke(m, _noclipRigid, args);
        }
    }

    _noclipApplied = YES;
}

/* ---------- 飞天 ---------- */

- (void)applyFly:(NSTimeInterval)now
{
    if (!self.flyOn) {
        _flyYValid = NO;
        return;
    }

    if (!_localPlayer) {
        _flyYValid = NO;
        return;
    }

    if (now - _lastFlyTick < ZK_MOVE_INTERVAL) return;
    _lastFlyTick = now;

    void *tr = zk_rt_get_transform(_localPlayer);
    if (!tr) return;

    ZKVec3 p = zk_rt_get_pos(_localPlayer);
    if (!_flyYValid) {
        _flyY = p.y;
        _flyYValid = YES;
    }

    float step = _flySpeed * (float)ZK_MOVE_INTERVAL;

    if (_flyMode == 1)      _flyY += step;
    else if (_flyMode == 2) _flyY -= step;
    else                    _flyY = MAX(_flyY, p.y);   /* 悬停:只托住不下坠 */

    /* 别飞太高,飞太高服务端一眼就看出来了 */
    if (_flyY < -50.0f) _flyY = -50.0f;
    if (_flyY > 400.0f) _flyY = 400.0f;

    p.y = _flyY;
    zk_rt_set_pos(tr, p);
}

/* ============================================================
   实体缓存
   ============================================================ */

- (NSArray *)entities
{
    NSTimeInterval now = CACurrentMediaTime();
    if (_entityCache && now - _entityStamp < 0.4) return _entityCache;

    NSArray *list = [self instancesOf:_playerClass];

    _entityCache = [list mutableCopy];
    _entityStamp = now;
    return _entityCache;
}

/* ============================================================
   透视数据
   ============================================================ */

- (int)fillBoxes:(ZKEspBox *)buf max:(int)maxCount
{
    self.espCount = 0;
    if (!buf || maxCount <= 0) return 0;
    if (!self.espOn) return 0;

    [self refreshCamera];
    if (!_camera || !_mW2S || !_playerClass) return 0;

    NSArray *all = [self entities];
    if (!all.count) return 0;

    ZKVec3 camPos = zk_rt_get_pos(_camera);

    CGFloat scale   = [UIScreen mainScreen].scale;
    CGSize  pts     = [UIScreen mainScreen].bounds.size;
    float   screenH = (float)(pts.height * scale);

    int teamLocal = (_fTeam && _localPlayer) ? zk_rt_field_get_int(_localPlayer, _fTeam) : INT32_MIN;
    int count = 0;

    for (NSValue *v in all) {
        if (count >= maxCount) break;

        void *ent = [v pointerValue];
        if (!ent || !zk_looks_like_obj(ent)) continue;

        BOOL isLocal = (ent == _localPlayer);
        if (isLocal && !self.markLocalOn) continue;

        ZKVec3 wp = zk_rt_get_pos(ent);
        if (!(wp.x == wp.x) || !(wp.y == wp.y)) continue;      /* NaN */

        float dx = wp.x - camPos.x, dy = wp.y - camPos.y, dz = wp.z - camPos.z;
        float dist = sqrtf(dx * dx + dy * dy + dz * dz);
        if (dist <= 0.1f || dist > ZK_ESP_MAX_DIST) continue;

        ZKVec3 input = wp;
        void *args[1] = { &input };
        void *ret = zk_rt_invoke(_mW2S, _camera, args);
        ZKVec3 sp = zk_rt_read_vec3_ret(ret);

        if (!(sp.x == sp.x) || !(sp.z == sp.z)) continue;
        if (sp.z < 0.0f) continue;                              /* 在相机后面 */

        float sx = sp.x / (float)scale;
        float sy = (screenH - sp.y) / (float)scale;
        if (sx < -200 || sy < -200) continue;
        if (sx > pts.width + 200 || sy > pts.height + 200) continue;

        float h = 1600.0f / dist;
        if (h > 240.0f) h = 240.0f;
        if (h < 18.0f)  h = 18.0f;
        float w = h * 0.55f;

        int enemy = -1;
        if (teamLocal != INT32_MIN && _fTeam) {
            int t = zk_rt_field_get_int(ent, _fTeam);
            enemy = (t == teamLocal) ? 0 : 1;
        }

        ZKEspBox *b = &buf[count];
        b->x = sx - w * 0.5f;
        b->y = sy - h;                 /* Unity 的 y 是脚底位置 */
        b->w = w;
        b->h = h;
        b->dist = dist;
        b->isLocal = isLocal ? 1 : 0;
        b->isEnemy = enemy;

        if (isLocal) snprintf(b->label, sizeof(b->label), "本地 %.0fm", dist);
        else         snprintf(b->label, sizeof(b->label), "%.0fm", dist);

        count++;
    }

    self.espCount = count;
    return count;
}

/* ============================================================
   状态 / 报告
   ============================================================ */

- (NSArray<NSString *> *)statusLines
{
    NSMutableArray *lines = [NSMutableArray array];

    [lines addObject:[NSString stringWithFormat:@"玩家类:%@", _playerClass ? @(zk_rt_class_name(_playerClass)) : @"未识别(看报告)"]];
    [lines addObject:[NSString stringWithFormat:@"实体 %d 个 · 相机%@", self.entityCount, _camera ? @"OK" : @"缺"]];

    if (_localMode) [lines addObject:[NSString stringWithFormat:@"本地玩家:%@", _localMode]];
    else            [lines addObject:@"本地玩家:未识别"];

    [lines addObject:[NSString stringWithFormat:@"移速:%@ · 冷却:%@ · 遁地:%@",
                      self.speedBound ? @"绑定" : @"无",
                      self.cooldownBound ? @"绑定" : @"无",
                      self.noclipBound ? @"绑定" : @"无"]];

    if (self.antiBanOn) {
        [lines addObject:[NSString stringWithFormat:@"防封:开 · 已拦 %d 处检测", self.antiCheatPatched]];
    } else {
        [lines addObject:@"防封:关(不建议)"];
    }

    if (_missing.count) {
        [lines addObject:[NSString stringWithFormat:@"未绑定 %lu 项(导出报告发我)", (unsigned long)_missing.count]];
    }

    return lines;
}

- (NSString *)fullReport
{
    NSMutableString *s = [NSMutableString string];

    [s appendString:@"===== EggyHack 扫描报告 =====\n"];
    [s appendString:[NSString stringWithFormat:@"生成时间: %@\n", [NSDate date]]];
    [s appendString:[NSString stringWithFormat:@"IL2CPP: %@ · 类表 %d 个类\n",
                     zk_rt_ready() ? @"就绪" : @"未就绪", zk_rt_class_count()]];
    [s appendString:[NSString stringWithFormat:@"识别到玩家类: %@\n",
                     _playerClass ? @(zk_rt_class_name(_playerClass)) : @"无"]];
    [s appendString:[NSString stringWithFormat:@"本地玩家判定: %@\n", _localMode ?: @"无"]];
    [s appendString:[NSString stringWithFormat:@"相机: %@\n", _camera ? @"OK" : @"无"]];
    [s appendString:[NSString stringWithFormat:@"实体数: %d · 透视框: %d\n", self.entityCount, self.espCount]];

    [s appendString:@"\n----- 玩家类候选(按分排序)-----\n"];
    if (_candidates.count) for (NSString *l in _candidates) [s appendFormat:@"%@\n", l];
    else [s appendString:@"  (没有候选,说明类名跟预期差很远)\n"];

    [s appendString:@"\n----- 移速字段 -----\n"];
    if (_speedSlots.count) for (ZKSlot *sl in _speedSlots) [s appendFormat:@"  %@\n", sl.desc];
    else [s appendString:@"  无\n"];

    [s appendString:@"\n----- 冷却字段 -----\n"];
    if (_cooldownSlots.count) for (ZKSlot *sl in _cooldownSlots) [s appendFormat:@"  %@\n", sl.desc];
    else [s appendString:@"  无\n"];

    [s appendString:@"\n----- 扫描过程 -----\n"];
    for (NSString *l in _log) [s appendFormat:@"  %@\n", l];

    [s appendString:@"\n----- 未绑定 -----\n"];
    if (_missing.count) for (NSString *l in _missing) [s appendFormat:@"  %@\n", l];
    else [s appendString:@"  无\n"];

    [s appendString:@"\n----- 防封 -----\n"];
    [s appendString:zk_antiban_report()];

    [s appendString:@"\n===== 报告结束 =====\n"];
    return s;
}

- (NSString *)reportPath
{
    NSString *dir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    return [dir stringByAppendingPathComponent:@"EggyHack_report.txt"];
}

- (BOOL)exportReport
{
    NSString *text = [self fullReport];
    return [text writeToFile:[self reportPath] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}

/* ============================================================
   防封开关
   ============================================================ */

- (void)setAntiBanEnabled:(BOOL)on
{
    self.antiBanOn = on;

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setBool:on forKey:@"zk_antiban"];
    [d synchronize];

    if (on) {
        zk_antiban_install_early();
        zk_antiban_scan_unity();
        self.antiCheatPatched = zk_antiban_patched_count();
    } else {
        zk_antiban_unpatch_unity();
        self.antiCheatPatched = 0;
    }
}

/* 属性 setter:改数值的时候立刻落盘(悬浮窗拉的滑块) */
- (void)setSpeedMul:(float)v
{
    _speedMul = MAX(ZK_SPEED_MIN, MIN(ZK_SPEED_MAX, v));
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setFloat:_speedMul forKey:@"zk_speed"];
}

- (void)setFlySpeed:(float)v
{
    _flySpeed = MAX(ZK_FLY_MIN, MIN(ZK_FLY_MAX, v));
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setFloat:_flySpeed forKey:@"zk_fly"];
}

@end
