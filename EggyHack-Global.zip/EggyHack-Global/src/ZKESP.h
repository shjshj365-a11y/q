//
//  ZKESP.h
//  透视层:一个不吃触摸的全屏窗口,每帧把实体投影成方框画出来
//

#ifndef ZK_ESP_H
#define ZK_ESP_H

#import <Foundation/Foundation.h>

@interface ZKESPView : NSObject

/// 建好透视层(不显示不代表不画,是否画由引擎的 espOn 决定)。
+ (void)install;

@end

#endif /* ZK_ESP_H */
