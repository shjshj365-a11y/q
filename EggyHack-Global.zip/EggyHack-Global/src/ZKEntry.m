//
//  ZKEntry.m
//  入口 —— 用 __attribute__((constructor)),不依赖 substrate / Logos,
//  所以这个 dylib 是零外部依赖的,重签后直接能加载。
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "ZKConfig.h"
#import "ZKEngine.h"
#import "ZKMenu.h"
#import "ZKESP.h"
#import "ZKAntiBan.h"

static void zk_setup_ui(void)
{
    @autoreleasepool {
        [ZKESPView install];
        [ZKMenu install];
        [[ZKEngine shared] bootstrap];
    }
}

__attribute__((constructor))
static void zk_entry(void)
{
    @autoreleasepool {
        ZKLOG(@"dylib 已加载 pid=%d", getpid());

        /* 防封的最早期动作:必须在游戏自己的检测跑起来之前 */
        zk_antiban_install_early();

        /* UI 等主线程 & 游戏窗口就绪之后再建 */
        dispatch_async(dispatch_get_main_queue(), ^{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                zk_setup_ui();
            });
        });
    }
}
