//
//  ZKMenu.h
//  悬浮窗:悬浮球 + 功能面板
//

#ifndef ZK_MENU_H
#define ZK_MENU_H

#import <Foundation/Foundation.h>

@interface ZKMenu : NSObject

/// 建悬浮窗(主线程调用)。
+ (void)install;

@end

#endif /* ZK_MENU_H */
