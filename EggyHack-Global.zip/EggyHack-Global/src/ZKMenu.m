//
//  ZKMenu.m
//

#import "ZKMenu.h"
#import "ZKEngine.h"
#import "ZKUI.h"
#import "ZKConfig.h"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define ZK_PANEL_W       246.0f
#define ZK_PANEL_PAD     10.0f
#define ZK_BALL_SIZE     52.0f
#define ZK_PANEL_MAXH    430.0f

/* 控件 tag 映射 */
enum {
    ZKTagEsp = 1,
    ZKTagFly,
    ZKTagNoclip,
    ZKTagSpeed,
    ZKTagCd,
    ZKTagAntiBan,
    ZKTagMark,
};

enum {
    ZKTagSliderSpeed = 100,
    ZKTagSliderFly,
};

enum {
    ZKTagFlyUp = 201,
    ZKTagFlyHold,
    ZKTagFlyDown,
    ZKTagExport,
    ZKTagHide,
};

/* ============================================================
   根视图:只有球和面板吃触摸,别的地方直接穿透给游戏
   ============================================================ */

@interface ZKMenuRootView : UIView
@property (nonatomic, assign) CGRect ballFrame;
@property (nonatomic, assign) CGRect panelFrame;
@end

@implementation ZKMenuRootView

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if (!CGRectIsEmpty(self.ballFrame) && CGRectContainsPoint(self.ballFrame, point)) return YES;
    if (!CGRectIsEmpty(self.panelFrame) && CGRectContainsPoint(self.panelFrame, point)) return YES;
    return NO;
}

@end

/* ============================================================
   悬浮窗
   ============================================================ */

@interface ZKMenuWindow : UIWindow
@end

@implementation ZKMenuWindow
@end

@interface ZKMenuController : NSObject
- (void)install;
- (void)buildBall;
- (void)buildPanel;
- (void)moveBallTo:(CGPoint)center;
- (void)layoutPanel;
- (UILabel *)label:(NSString *)text size:(CGFloat)size color:(UIColor *)color y:(CGFloat *)y;
- (UISwitch *)addSwitch:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y;
- (UISwitch *)addSwitch:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y on:(BOOL)on;
- (UISlider *)addSlider:(NSInteger)tag min:(float)mn max:(float)mx value:(float)v y:(CGFloat *)y;
- (void)addButtonsY:(CGFloat *)y;
- (UIButton *)addButton:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y;
- (void)switchChanged:(UISwitch *)sw;
- (void)sliderChanged:(UISlider *)s;
- (void)flyButton:(UIButton *)b;
- (void)buttonTapped:(UIButton *)b;
- (void)exportReport;
- (void)refreshStatus;
- (void)ballTapped;
- (void)ballPanned:(UIPanGestureRecognizer *)g;
@end

@implementation ZKMenuController
{
    ZKMenuWindow *_win;
    ZKMenuRootView *_root;
    UIButton *_ball;
    UIView *_panel;
    UIScrollView *_scroll;
    UILabel *_status;

    UILabel *_speedVal;
    UILabel *_flyVal;

    UISwitch *_flySwitch;
    UISwitch *_speedSwitch;

    BOOL _panelOpen;
    NSTimer *_statusTimer;
    CGPoint _ballCenter;
}

+ (instancetype)shared
{
    static ZKMenuController *c = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ c = [[ZKMenuController alloc] init]; });
    return c;
}

- (void)install
{
    _win = (ZKMenuWindow *)zk_make_overlay_window(200);

    _root = [[ZKMenuRootView alloc] initWithFrame:_win.bounds];
    _root.backgroundColor = [UIColor clearColor];
    _root.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _win.rootViewController.view = _root;

    [self buildBall];
    [self buildPanel];

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    CGFloat bx = [d objectForKey:@"zk_ball_x"] ? [d floatForKey:@"zk_ball_x"] : 14.0f;
    CGFloat by = [d objectForKey:@"zk_ball_y"] ? [d floatForKey:@"zk_ball_y"] : 120.0f;
    [self moveBallTo:CGPointMake(bx, by)];

    _panelOpen = NO;
    _panel.hidden = YES;

    _statusTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                    target:self
                                                  selector:@selector(refreshStatus)
                                                  userInfo:nil
                                                   repeats:YES];
    ZKLOG(@"悬浮窗已装");
}

/* ---------- 悬浮球 ---------- */

- (void)buildBall
{
    _ball = [UIButton buttonWithType:UIButtonTypeCustom];
    _ball.frame = CGRectMake(0, 0, ZK_BALL_SIZE, ZK_BALL_SIZE);
    _ball.layer.cornerRadius = ZK_BALL_SIZE / 2.0f;
    _ball.layer.masksToBounds = YES;
    _ball.backgroundColor = [UIColor colorWithRed:0.10 green:0.55 blue:1.00 alpha:0.85];
    _ball.layer.borderWidth = 1.5;
    _ball.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.6].CGColor;
    _ball.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [_ball setTitle:@"ZK" forState:UIControlStateNormal];
    [_ball setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

    [_ball addTarget:self action:@selector(ballTapped) forControlEvents:UIControlEventTouchUpInside];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(ballPanned:)];
    [_ball addGestureRecognizer:pan];

    [_root addSubview:_ball];
}

- (void)moveBallTo:(CGPoint)center
{
    CGSize screen = _root.bounds.size;
    CGFloat half = ZK_BALL_SIZE / 2.0f;

    center.x = MAX(half + 2, MIN(screen.width - half - 2, center.x));
    center.y = MAX(half + 30, MIN(screen.height - half - 2, center.y));

    _ballCenter = center;
    _ball.center = center;
    _root.ballFrame = _ball.frame;

    [self layoutPanel];

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setFloat:center.x forKey:@"zk_ball_x"];
    [d setFloat:center.y forKey:@"zk_ball_y"];
}

- (void)ballTapped
{
    _panelOpen = !_panelOpen;
    _panel.hidden = !_panelOpen;
    [self layoutPanel];
}

- (void)ballPanned:(UIPanGestureRecognizer *)g
{
    CGPoint t = [g translationInView:_root];
    [self moveBallTo:CGPointMake(_ballCenter.x + t.x, _ballCenter.y + t.y)];
    [g setTranslation:CGPointZero inView:_root];
}

/* ---------- 面板 ---------- */

- (void)layoutPanel
{
    CGFloat screenH = _root.bounds.height;
    CGFloat screenW = _root.bounds.width;

    CGFloat h = MIN(ZK_PANEL_MAXH, screenH - 60.0f);
    CGFloat x = _ballCenter.x + ZK_BALL_SIZE / 2.0f + 8.0f;
    if (x + ZK_PANEL_W > screenW - 6.0f) {
        x = _ballCenter.x - ZK_BALL_SIZE / 2.0f - 8.0f - ZK_PANEL_W;
    }
    x = MAX(6.0f, MIN(screenW - ZK_PANEL_W - 6.0f, x));

    CGFloat y = _ballCenter.y - 40.0f;
    y = MAX(30.0f, MIN(screenH - h - 6.0f, y));

    _panel.frame = CGRectMake(x, y, ZK_PANEL_W, h);
    _root.panelFrame = _panelOpen ? _panel.frame : CGRectZero;
}

- (UILabel *)label:(NSString *)text size:(CGFloat)size color:(UIColor *)color y:(CGFloat *)y
{
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(ZK_PANEL_PAD, *y, ZK_PANEL_W - ZK_PANEL_PAD * 2, size + 6)];
    l.text = text;
    l.font = [UIFont systemFontOfSize:size];
    l.textColor = color;
    l.numberOfLines = 0;
    [_scroll addSubview:l];
    *y += l.frame.size.height + 4;
    return l;
}

- (void)buildPanel
{
    _panel = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ZK_PANEL_W, ZK_PANEL_MAXH)];
    _panel.backgroundColor = [UIColor colorWithRed:0.06 green:0.07 blue:0.11 alpha:0.94];
    _panel.layer.cornerRadius = 12;
    _panel.layer.borderWidth = 1;
    _panel.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.15].CGColor;
    _panel.layer.masksToBounds = YES;
    [_root addSubview:_panel];

    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ZK_PANEL_W, ZK_PANEL_MAXH)];
    _scroll.alwaysBounceVertical = YES;
    [_panel addSubview:_scroll];

    CGFloat y = 10.0f;

    UILabel *title = [self label:@"Zaka · 蛋仔国际服" size:14 color:[UIColor whiteColor] y:&y];
    title.font = [UIFont boldSystemFontOfSize:14];

    /* 状态区 */
    _status = [self label:@"扫描中…" size:11 color:[UIColor colorWithWhite:0.75 alpha:1] y:&y];
    _status.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
    _status.layer.cornerRadius = 6;
    _status.layer.masksToBounds = YES;
    y += 2;

    /* 开关 */
    _speedSwitch = [self addSwitch:@"加速" tag:ZKTagSpeed y:&y];
    _flySwitch   = [self addSwitch:@"飞天" tag:ZKTagFly y:&y];
    [self addSwitch:@"遁地 / 穿墙" tag:ZKTagNoclip y:&y];

    [self addSwitch:@"透视" tag:ZKTagEsp y:&y];
    [self addSwitch:@"技能无冷却" tag:ZKTagCd y:&y];
    [self addSwitch:@"防封" tag:ZKTagAntiBan y:&y on:[[ZKEngine shared] antiBanOn]];
    [self addSwitch:@"高亮本地玩家(自检)" tag:ZKTagMark y:&y];

    /* 滑条 */
    _speedVal = [self label:[NSString stringWithFormat:@"移速 x%.2f", [ZKEngine shared].speedMul]
                       size:11 color:[UIColor colorWithWhite:0.8 alpha:1] y:&y];
    [self addSlider:ZKTagSliderSpeed min:ZK_SPEED_MIN max:ZK_SPEED_MAX value:[ZKEngine shared].speedMul y:&y];

    _flyVal = [self label:[NSString stringWithFormat:@"飞天速度 %.1f", [ZKEngine shared].flySpeed]
                     size:11 color:[UIColor colorWithWhite:0.8 alpha:1] y:&y];
    [self addSlider:ZKTagSliderFly min:ZK_FLY_MIN max:ZK_FLY_MAX value:[ZKEngine shared].flySpeed y:&y];

    /* 飞天三键 */
    [self addButtonsY:&y];

    /* 底部 */
    UIButton *export = [self addButton:@"导出扫描报告" tag:ZKTagExport y:&y];
    export.backgroundColor = [UIColor colorWithRed:0.15 green:0.45 blue:0.85 alpha:1];

    [self addButton:@"隐藏悬浮球" tag:ZKTagHide y:&y];

    [self label:@"点『上升』就一直升,点『停』悬停" size:10 color:[UIColor colorWithWhite:0.5 alpha:1] y:&y];

    _scroll.contentSize = CGSizeMake(ZK_PANEL_W, y + 12);
}

- (UISwitch *)addSwitch:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y
{
    return [self addSwitch:title tag:tag y:y on:NO];
}

- (UISwitch *)addSwitch:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y on:(BOOL)on
{
    UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, *y, ZK_PANEL_W, 30)];
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(ZK_PANEL_PAD, 0, ZK_PANEL_W - 80, 30)];
    l.text = title;
    l.font = [UIFont systemFontOfSize:13];
    l.textColor = [UIColor colorWithWhite:0.92 alpha:1];
    [row addSubview:l];

    UISwitch *sw = [[UISwitch alloc] initWithFrame:CGRectMake(ZK_PANEL_W - 62, 2, 51, 26)];
    sw.transform = CGAffineTransformMakeScale(0.82f, 0.82f);
    sw.tag = tag;
    sw.on = on;
    [sw addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    [row addSubview:sw];

    [_scroll addSubview:row];
    *y += 32;
    return sw;
}

- (UISlider *)addSlider:(NSInteger)tag min:(float)mn max:(float)mx value:(float)v y:(CGFloat *)y
{
    UISlider *s = [[UISlider alloc] initWithFrame:CGRectMake(ZK_PANEL_PAD, *y, ZK_PANEL_W - ZK_PANEL_PAD * 2, 26)];
    s.minimumValue = mn;
    s.maximumValue = mx;
    s.value = v;
    s.tag = tag;
    [s addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    [_scroll addSubview:s];
    *y += 28;
    return s;
}

- (void)addButtonsY:(CGFloat *)y
{
    NSArray *titles = @[ @"↑ 上升", @"停 悬停", @"↓ 下降" ];
    NSArray *tags   = @[ @(ZKTagFlyUp), @(ZKTagFlyHold), @(ZKTagFlyDown) ];

    CGFloat w = (ZK_PANEL_W - ZK_PANEL_PAD * 2 - 8) / 3.0f;

    for (int i = 0; i < 3; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        b.frame = CGRectMake(ZK_PANEL_PAD + i * (w + 4), *y, w, 30);
        b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.12];
        b.layer.cornerRadius = 7;
        b.titleLabel.font = [UIFont boldSystemFontOfSize:12];
        b.tag = [tags[i] integerValue];
        [b setTitle:titles[i] forState:UIControlStateNormal];
        [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [b addTarget:self action:@selector(flyButton:) forControlEvents:UIControlEventTouchUpInside];
        [_scroll addSubview:b];
    }
    *y += 36;
}

- (UIButton *)addButton:(NSString *)title tag:(NSInteger)tag y:(CGFloat *)y
{
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = CGRectMake(ZK_PANEL_PAD, *y, ZK_PANEL_W - ZK_PANEL_PAD * 2, 32);
    b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.12];
    b.layer.cornerRadius = 7;
    b.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    b.tag = tag;
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [b addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [_scroll addSubview:b];
    *y += 36;
    return b;
}

/* ---------- 交互 ---------- */

- (void)switchChanged:(UISwitch *)sw
{
    ZKEngine *e = [ZKEngine shared];

    switch (sw.tag) {
        case ZKTagEsp:     e.espOn = sw.on; break;
        case ZKTagFly:     e.flyOn = sw.on; break;
        case ZKTagNoclip:  e.noclipOn = sw.on; break;
        case ZKTagSpeed:   e.speedOn = sw.on; break;
        case ZKTagCd:      e.cooldownOn = sw.on; break;
        case ZKTagMark:    e.markLocalOn = sw.on; break;
        case ZKTagAntiBan: [e setAntiBanEnabled:sw.on]; break;
        default: break;
    }
    [self refreshStatus];
}

- (void)sliderChanged:(UISlider *)s
{
    ZKEngine *e = [ZKEngine shared];

    if (s.tag == ZKTagSliderSpeed) {
        e.speedMul = s.value;
        _speedVal.text = [NSString stringWithFormat:@"移速 x%.2f", e.speedMul];
    } else if (s.tag == ZKTagSliderFly) {
        e.flySpeed = s.value;
        _flyVal.text = [NSString stringWithFormat:@"飞天速度 %.1f", e.flySpeed];
    }
}

- (void)flyButton:(UIButton *)b
{
    ZKEngine *e = [ZKEngine shared];

    if (b.tag == ZKTagFlyUp)        e.flyMode = 1;
    else if (b.tag == ZKTagFlyDown) e.flyMode = 2;
    else                            e.flyMode = 0;

    /* 点方向键顺手把飞天打开,少一步操作 */
    if (b.tag != ZKTagFlyHold) {
        e.flyOn = YES;
        _flySwitch.on = YES;
    }
    [self refreshStatus];
}

- (void)buttonTapped:(UIButton *)b
{
    if (b.tag == ZKTagExport) {
        [self exportReport];
    } else if (b.tag == ZKTagHide) {
        _panelOpen = NO;
        _panel.hidden = YES;
        _root.panelFrame = CGRectZero;
        _ball.alpha = 0.18;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            self->_ball.alpha = 0.85;
        });
    }
}

- (void)exportReport
{
    ZKEngine *e = [ZKEngine shared];
    BOOL ok = [e exportReport];

    if (!ok) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"导出失败"
                                                                   message:@"报告写不出来,换个地方再试"
                                                            preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
        [_win.rootViewController presentViewController:a animated:YES completion:nil];
        return;
    }

    NSURL *url = [NSURL fileURLWithPath:[e reportPath]];
    UIActivityViewController *vc = [[UIActivityViewController alloc] initWithActivityItems:@[ url ]
                                                                    applicationActivities:nil];
    if (vc.popoverPresentationController) {
        vc.popoverPresentationController.sourceView = _panel;
        vc.popoverPresentationController.sourceRect = _panel.bounds;
    }
    [_win.rootViewController presentViewController:vc animated:YES completion:nil];
}

- (void)refreshStatus
{
    if (!_panelOpen) return;

    NSArray<NSString *> *lines = [[ZKEngine shared] statusLines];
    _status.text = [lines componentsJoinedByString:@"\n"];
}

@end

/* ============================================================
   对外入口
   ============================================================ */

@implementation ZKMenu

+ (void)install
{
    [[ZKMenuController shared] install];
}

@end
