//
//  ZKIL2CPP.h
//  Unity IL2CPP 运行时接口 —— 全量封装
//
//  设计原则:一个符号都不硬编码地址。
//  类 / 方法 / 字段全部按名字在运行时查,游戏小版本更新只要类名没改就不用重编。
//

#ifndef ZK_IL2CPP_H
#define ZK_IL2CPP_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

typedef struct Il2CppClass   Il2CppClass;
typedef struct Il2CppImage   Il2CppImage;
typedef struct Il2CppObject  Il2CppObject;
typedef struct MethodInfo    MethodInfo;
typedef struct FieldInfo     FieldInfo;

typedef struct ZKVec3 { float x, y, z; } ZKVec3;

/* 打补丁的返回类型 */
typedef enum {
    ZK_RET_VOID = 0,
    ZK_RET_FALSE,
    ZK_RET_TRUE,
    ZK_RET_ZERO_INT,
} ZKRetKind;

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================
   初始化
   ============================================================ */

/// 连接 UnityFramework 的 il2cpp 导出表。必须等 Unity 起来之后再调。
bool zk_rt_init(void);
bool zk_rt_ready(void);

/// 非 Unity 线程上调用 Unity API 之前必须先 attach。
void zk_rt_attach_thread(void);

/* ============================================================
   类表
   ============================================================ */

int   zk_rt_class_count(void);              ///< 首次调用会构建全量类表(几十毫秒)
Il2CppClass *zk_rt_class_at(int idx);

const char  *zk_rt_class_name(Il2CppClass *k);
const char  *zk_rt_class_ns(Il2CppClass *k);
const char  *zk_rt_class_image(Il2CppClass *k);     ///< 所在 assembly 名
Il2CppClass  *zk_rt_class_parent(Il2CppClass *k);

/// 按简单类名找(不区分命名空间);重名时优先非 Editor / 非 Test 的。
Il2CppClass  *zk_rt_find_class(const char *name);

/// 在指定 assembly 里找。
Il2CppClass  *zk_rt_find_class_in(const char *assembly, const char *ns, const char *name);

/// 类名(小写后)是否包含 sub。自己不做大小写转换。
bool zk_rt_class_name_has(Il2CppClass *k, const char *sub);
/// 忽略大小写版本。
bool zk_rt_class_name_has_nocase(Il2CppClass *k, const char *sub);

/* ============================================================
   字段
   ============================================================ */

FieldInfo   *zk_rt_field_first(Il2CppClass *k, void **iter);
const char  *zk_rt_field_name(FieldInfo *f);
const char  *zk_rt_field_type(FieldInfo *f);         ///< 完整类型名,如 "System.Single"
size_t       zk_rt_field_offset(FieldInfo *f);
bool         zk_rt_field_is_static(FieldInfo *f);

void        *zk_rt_field_addr(void *obj, FieldInfo *f);      ///< 实例字段的内存地址
void        *zk_rt_field_get_obj(void *obj, FieldInfo *f);   ///< 读引用类型字段
bool         zk_rt_field_set_obj(void *obj, FieldInfo *f, void *v);

bool         zk_rt_field_static_get(FieldInfo *f, void *out);
bool         zk_rt_field_static_set(FieldInfo *f, const void *v);

float        zk_rt_field_get_float(void *obj, FieldInfo *f);
void         zk_rt_field_set_float(void *obj, FieldInfo *f, float v);
int32_t      zk_rt_field_get_int(void *obj, FieldInfo *f);
void         zk_rt_field_set_int(void *obj, FieldInfo *f, int32_t v);
bool         zk_rt_field_get_bool(void *obj, FieldInfo *f);
void         zk_rt_field_set_bool(void *obj, FieldInfo *f, bool v);

/// 在类(含父类)里按名字找字段。
FieldInfo   *zk_rt_find_field(Il2CppClass *k, const char *name);

/* ============================================================
   方法
   ============================================================ */

MethodInfo  *zk_rt_method_first(Il2CppClass *k, void **iter);
const char  *zk_rt_method_name(MethodInfo *m);
int          zk_rt_method_argc(MethodInfo *m);
const char  *zk_rt_method_ret(MethodInfo *m);        ///< 返回类型名
void        *zk_rt_method_ptr(MethodInfo *m);        ///< 真实入口地址

MethodInfo  *zk_rt_class_method(Il2CppClass *k, const char *name, int argc); /* argc<0 不限 */
MethodInfo  *zk_rt_obj_method(void *obj, const char *name, int argc);        /* 沿父类链找 */

/// 调用(argc 个参数,args 是 void* 数组;值类型传值本身的地址)。
void        *zk_rt_invoke(MethodInfo *m, void *obj, void **args);
void        *zk_rt_invoke_on(void *obj, const char *name, int argc, void **args);

/// 拆箱:值类型返回值是装箱的,拿数据要过这一道。
void        *zk_rt_unbox(void *obj);
/// 从"值类型返回指针"里读一个 Vector3。装箱/未装箱两种都兼容。
ZKVec3       zk_rt_read_vec3_ret(void *ret);
/// 从"值类型返回指针"里读一个 float。
float        zk_rt_read_float_ret(void *ret);

/* ============================================================
   通用
   ============================================================ */

Il2CppClass *zk_rt_obj_class(void *obj);
void        *zk_rt_type_obj(Il2CppClass *k);   ///< System.Type 对象,FindObjectsOfType 用
int          zk_rt_array_len(void *arr);
void        *zk_rt_array_at(void *arr, int i);

/// 拿对象所属类的名字(带 16 字节头校验,拿不到返回 NULL)。
const char  *zk_rt_obj_class_name(void *obj);

/* ============================================================
   坐标(UnityEngine.Transform / Component)
   ============================================================ */

void  *zk_rt_get_transform(void *component);
ZKVec3 zk_rt_get_pos(void *componentOrTransform);
bool   zk_rt_set_pos(void *transform, ZKVec3 p);

/* ============================================================
   打补丁(不需要 hook 库)
   ============================================================ */

/// 把方法入口改成直接返回(方法内容会被跳过),同时把原 8 字节记下来。
bool zk_rt_patch_method(MethodInfo *m, ZKRetKind kind);
/// 还原。
bool zk_rt_unpatch_method(MethodInfo *m);
/// 这个方法打过补丁吗。
bool zk_rt_method_patched(MethodInfo *m);
/// 已打补丁数量。
int  zk_rt_patch_count(void);

#ifdef __cplusplus
}
#endif

#endif /* ZK_IL2CPP_H */
