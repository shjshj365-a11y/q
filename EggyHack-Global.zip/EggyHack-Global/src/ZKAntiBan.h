//
//  ZKAntiBan.h
//  防封模块
//
//  说明(实话):
//    不越狱的机器上,任何"防封"都只能降低【本地被识别】的概率,
//    跑不出"服务端风控"这一层。改位移/速度这种数据本身就是异常,
//    服务端一统计就知道。这里的做法是:
//      1. 尽早把常见检测点掐掉(调试检测 / 越狱检测 / 环境检测)
//      2. 把游戏自己的反作弊逻辑改成直接返回"没事"
//      3. 不写任何异常数值,不刷频率,不留日志
//

#ifndef ZK_ANTIBAN_H
#define ZK_ANTIBAN_H

#import <Foundation/Foundation.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/// 尽早调用(越早越好):调试检测 / 越狱检测 / 环境检测的封堵。可重复调用,幂等。
bool zk_antiban_install_early(void);

/// Unity 起来之后调用:扫描游戏自带的反作弊方法并打补丁。
void zk_antiban_scan_unity(void);

/// 还原上面打的补丁。
void zk_antiban_unpatch_unity(void);

int  zk_antiban_patched_count(void);

NSString *zk_antiban_report(void);

#ifdef __cplusplus
}
#endif

#endif /* ZK_ANTIBAN_H */
