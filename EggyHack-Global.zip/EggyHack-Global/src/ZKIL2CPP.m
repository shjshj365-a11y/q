//
//  ZKIL2CPP.m
//

#import "ZKIL2CPP.h"
#import "ZKMem.h"
#import "ZKConfig.h"

#import <Foundation/Foundation.h>
#import <dlfcn.h>
#import <string.h>
#import <stdlib.h>

/* ============================================================
   结构布局
   ============================================================ */

/* MethodInfo:各 IL2CPP 版本字段略有差异,但 methodPointer 永远是第一个指针。 */
struct MethodInfo {
    void        *methodPointer;
    void        *virtualMethodPointer;
    void        *invoker_method;
    const char  *name;
    void        *klass;
    void        *return_type;
    void        *parameters;
    void        *methodMetadataHandle;
    void        *genericMethod;
    void        *genericContainerHandle;
    uint32_t     token;
    uint16_t     flags;
    uint16_t     iflags;
    uint16_t     slot;
    uint8_t      parameters_count;
    uint8_t      bitflags;
};

/* IL2CPP 数组:obj(klass+monitor 16B) + bounds(8B) + max_length(8B) + vector[] */
#define ZK_ARRAY_VECTOR_OFFSET 32

#define FIELD_ATTRIBUTE_STATIC 0x0010

/* ============================================================
   符号
   ============================================================ */

typedef void         *(*fn_domain_get)(void);
typedef const void  **(*fn_domain_get_assemblies)(void *domain, size_t *size);
typedef Il2CppImage  *(*fn_assembly_get_image)(const void *assembly);
typedef const char   *(*fn_image_get_name)(const Il2CppImage *image);
typedef size_t        (*fn_image_get_class_count)(const Il2CppImage *image);
typedef Il2CppClass  *(*fn_image_get_class)(const Il2CppImage *image, size_t index);

typedef const char   *(*fn_class_get_name)(Il2CppClass *k);
typedef const char   *(*fn_class_get_namespace)(Il2CppClass *k);
typedef Il2CppClass  *(*fn_class_get_parent)(Il2CppClass *k);
typedef const MethodInfo *(*fn_class_get_methods)(Il2CppClass *k, void **iter);
typedef FieldInfo    *(*fn_class_get_fields)(Il2CppClass *k, void **iter);
typedef MethodInfo   *(*fn_class_get_method_from_name)(Il2CppClass *k, const char *name, int argc);
typedef FieldInfo    *(*fn_class_get_field_from_name)(Il2CppClass *k, const char *name);

typedef const char   *(*fn_method_get_name)(const MethodInfo *m);
typedef uint32_t      (*fn_method_get_param_count)(const MethodInfo *m);
typedef const void   *(*fn_method_get_return_type)(const MethodInfo *m);

typedef const char   *(*fn_field_get_name)(FieldInfo *f);
typedef size_t        (*fn_field_get_offset)(FieldInfo *f);
typedef uint32_t      (*fn_field_get_flags)(FieldInfo *f);
typedef const void   *(*fn_field_get_type)(FieldInfo *f);
typedef void          (*fn_field_static_get)(FieldInfo *f, void *out);
typedef void          (*fn_field_static_set)(FieldInfo *f, void *in);

typedef char         *(*fn_type_get_name)(const void *type);
typedef void          (*fn_free)(void *p);
typedef void         *(*fn_type_get_object)(const void *type);
typedef const void   *(*fn_class_get_type)(Il2CppClass *k);

typedef void         *(*fn_runtime_invoke)(MethodInfo *m, void *obj, void **params, void **exc);
typedef void         *(*fn_object_unbox)(void *obj);
typedef void         *(*fn_thread_attach)(void *domain);
typedef Il2CppClass  *(*fn_object_get_class)(void *obj);
typedef uint32_t      (*fn_array_length)(void *arr);

static fn_domain_get                  p_domain_get;
static fn_domain_get_assemblies       p_domain_get_assemblies;
static fn_assembly_get_image          p_assembly_get_image;
static fn_image_get_name              p_image_get_name;
static fn_image_get_class_count       p_image_get_class_count;
static fn_image_get_class             p_image_get_class;
static fn_class_get_name              p_class_get_name;
static fn_class_get_namespace         p_class_get_namespace;
static fn_class_get_parent            p_class_get_parent;
static fn_class_get_methods           p_class_get_methods;
static fn_class_get_fields            p_class_get_fields;
static fn_class_get_method_from_name  p_class_get_method_from_name;
static fn_class_get_field_from_name   p_class_get_field_from_name;
static fn_method_get_name             p_method_get_name;
static fn_method_get_param_count      p_method_get_param_count;
static fn_method_get_return_type      p_method_get_return_type;
static fn_field_get_name              p_field_get_name;
static fn_field_get_offset            p_field_get_offset;
static fn_field_get_flags             p_field_get_flags;
static fn_field_get_type              p_field_get_type;
static fn_field_static_get            p_field_static_get;
static fn_field_static_set            p_field_static_set;
static fn_type_get_name               p_type_get_name;
static fn_free                        p_il2cpp_free;
static fn_type_get_object             p_type_get_object;
static fn_class_get_type              p_class_get_type;
static fn_runtime_invoke              p_runtime_invoke;
static fn_object_unbox                p_object_unbox;
static fn_thread_attach               p_thread_attach;
static fn_object_get_class            p_object_get_class;
static fn_array_length                p_array_length;

static void  *g_unityHandle   = NULL;
static bool   g_ready         = false;
static bool   g_attached      = false;
static int    g_missingSyms   = 0;

/* ============================================================
   取符号
   ============================================================ */

static void *zk_sym(const char *name)
{
    void *p = dlsym(RTLD_DEFAULT, name);
    if (p) return p;

    if (!g_unityHandle) {
        const char *path = zk_image_path("UnityFramework");
        if (path) g_unityHandle = dlopen(path, RTLD_NOW | RTLD_GLOBAL);
    }
    if (g_unityHandle) p = dlsym(g_unityHandle, name);
    return p;
}

#define ZK_BIND(var, name)                                  \
    do {                                                    \
        *(void **)(&p_##var) = zk_sym(name);                \
        if (!p_##var) g_missingSyms++;                      \
    } while (0)

/* ============================================================
   初始化
   ============================================================ */

bool zk_rt_init(void)
{
    if (g_ready) return true;

    /* 关键符号缺一个就用不了,先探一下 UnityFramework 在不在 */
    if (!zk_sym("il2cpp_domain_get")) return false;

    g_missingSyms = 0;

    ZK_BIND(domain_get,              "il2cpp_domain_get");
    ZK_BIND(domain_get_assemblies,   "il2cpp_domain_get_assemblies");
    ZK_BIND(assembly_get_image,      "il2cpp_assembly_get_image");
    ZK_BIND(image_get_name,          "il2cpp_image_get_name");
    ZK_BIND(image_get_class_count,   "il2cpp_image_get_class_count");
    ZK_BIND(image_get_class,         "il2cpp_image_get_class");
    ZK_BIND(class_get_name,          "il2cpp_class_get_name");
    ZK_BIND(class_get_namespace,     "il2cpp_class_get_namespace");
    ZK_BIND(class_get_parent,        "il2cpp_class_get_parent");
    ZK_BIND(class_get_methods,       "il2cpp_class_get_methods");
    ZK_BIND(class_get_fields,        "il2cpp_class_get_fields");
    ZK_BIND(class_get_method_from_name, "il2cpp_class_get_method_from_name");
    ZK_BIND(class_get_field_from_name,  "il2cpp_class_get_field_from_name");
    ZK_BIND(method_get_name,         "il2cpp_method_get_name");
    ZK_BIND(method_get_param_count,  "il2cpp_method_get_param_count");
    ZK_BIND(method_get_return_type,  "il2cpp_method_get_return_type");
    ZK_BIND(field_get_name,          "il2cpp_field_get_name");
    ZK_BIND(field_get_offset,        "il2cpp_field_get_offset");
    ZK_BIND(field_get_flags,         "il2cpp_field_get_flags");
    ZK_BIND(field_get_type,          "il2cpp_field_get_type");
    ZK_BIND(field_static_get,        "il2cpp_field_static_get_value");
    ZK_BIND(field_static_set,        "il2cpp_field_static_set_value");
    ZK_BIND(type_get_name,           "il2cpp_type_get_name");
    ZK_BIND(il2cpp_free,             "il2cpp_free");
    ZK_BIND(type_get_object,         "il2cpp_type_get_object");
    ZK_BIND(class_get_type,          "il2cpp_class_get_type");
    ZK_BIND(runtime_invoke,          "il2cpp_runtime_invoke");
    ZK_BIND(object_unbox,            "il2cpp_object_unbox");
    ZK_BIND(thread_attach,           "il2cpp_thread_attach");
    ZK_BIND(object_get_class,        "il2cpp_object_get_class");
    ZK_BIND(array_length,            "il2cpp_array_length");

    /* 少了这几个核心的,直接判定没起来 */
    if (!p_domain_get || !p_domain_get_assemblies || !p_assembly_get_image ||
        !p_image_get_class_count || !p_image_get_class || !p_class_get_name) {
        return false;
    }

    g_ready = true;
    zk_rt_attach_thread();
    return true;
}

bool zk_rt_ready(void) { return g_ready; }

void zk_rt_attach_thread(void)
{
    if (!g_ready || !p_thread_attach || !p_domain_get) return;
    if (g_attached) return;
    p_thread_attach(p_domain_get());
    g_attached = true;
}

/* ============================================================
   类表
   ============================================================ */

typedef struct {
    Il2CppClass *klass;
    const char  *image;
} ZKClassEntry;

static ZKClassEntry *g_table    = NULL;
static int           g_tableLen = 0;
static bool          g_tableBuilt = false;

static void zk_build_table(void)
{
    if (g_tableBuilt || !g_ready) return;
    g_tableBuilt = true;

    size_t asmCount = 0;
    const void **asms = p_domain_get_assemblies(p_domain_get(), &asmCount);
    if (!asms) return;

    /* 先估个容量,避免反复 realloc */
    int cap = 4096;
    g_table = (ZKClassEntry *)calloc(cap, sizeof(ZKClassEntry));
    if (!g_table) return;

    for (size_t a = 0; a < asmCount; a++) {
        Il2CppImage *img = p_assembly_get_image(asms[a]);
        if (!img) continue;

        const char *imgName = p_image_get_name ? p_image_get_name(img) : "?";
        size_t count = p_image_get_class_count(img);

        for (size_t i = 0; i < count; i++) {
            Il2CppClass *k = p_image_get_class(img, i);
            if (!k) continue;

            if (g_tableLen >= cap) {
                cap *= 2;
                ZKClassEntry *bigger = (ZKClassEntry *)realloc(g_table, cap * sizeof(ZKClassEntry));
                if (!bigger) return;
                g_table = bigger;
            }
            g_table[g_tableLen].klass = k;
            g_table[g_tableLen].image = imgName;
            g_tableLen++;
        }
    }

    ZKLOG(@"类表建好:%d 个类 / %zu 个 assembly", g_tableLen, asmCount);
}

int zk_rt_class_count(void)
{
    zk_build_table();
    return g_tableLen;
}

Il2CppClass *zk_rt_class_at(int idx)
{
    zk_build_table();
    if (idx < 0 || idx >= g_tableLen) return NULL;
    return g_table[idx].klass;
}

const char *zk_rt_class_name(Il2CppClass *k)
{
    if (!k || !p_class_get_name) return NULL;
    return p_class_get_name(k);
}

const char *zk_rt_class_ns(Il2CppClass *k)
{
    if (!k || !p_class_get_namespace) return NULL;
    const char *ns = p_class_get_namespace(k);
    return ns ? ns : "";
}

const char *zk_rt_class_image(Il2CppClass *k)
{
    zk_build_table();
    for (int i = 0; i < g_tableLen; i++) {
        if (g_table[i].klass == k) return g_table[i].image;
    }
    return "?";
}

Il2CppClass *zk_rt_class_parent(Il2CppClass *k)
{
    if (!k || !p_class_get_parent) return NULL;
    return p_class_get_parent(k);
}

bool zk_rt_class_name_has(Il2CppClass *k, const char *sub)
{
    const char *n = zk_rt_class_name(k);
    if (!n || !sub) return false;
    return strstr(n, sub) != NULL;
}

/* 两个独立缓冲,因为一次比较要同时转两份字符串 */
static char zk_lower_bufA[256];
static char zk_lower_bufB[256];

static const char *zk_lower(const char *s, char *buf, size_t bufSize)
{
    if (!s) return "";
    size_t n = strlen(s);
    if (n >= bufSize) n = bufSize - 1;
    for (size_t i = 0; i < n; i++) {
        char c = s[i];
        buf[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
    }
    buf[n] = 0;
    return buf;
}

bool zk_rt_class_name_has_nocase(Il2CppClass *k, const char *sub)
{
    const char *n = zk_rt_class_name(k);
    if (!n || !sub) return false;

    const char *ln = zk_lower(n, zk_lower_bufA, sizeof(zk_lower_bufA));
    const char *ls = zk_lower(sub, zk_lower_bufB, sizeof(zk_lower_bufB));
    return strstr(ln, ls) != NULL;
}

static int zk_score_class_name(const char *name)
{
    if (!name) return -1000;
    int score = 0;
    /* 排除明显不相关的 */
    if (strstr(name, "Editor"))  score -= 50;
    if (strstr(name, "Test"))    score -= 30;
    if (strstr(name, "Debug"))   score -= 20;
    if (strstr(name, "Dummy"))   score -= 20;
    if (strstr(name, "Preview")) score -= 20;
    if (strstr(name, "<"))       score -= 60;   /* 编译器生成的 */
    return score;
}

Il2CppClass *zk_rt_find_class(const char *name)
{
    zk_build_table();
    if (!name) return NULL;

    Il2CppClass *best = NULL;
    int bestScore = -10000;

    for (int i = 0; i < g_tableLen; i++) {
        Il2CppClass *k = g_table[i].klass;
        const char *cn = zk_rt_class_name(k);
        if (!cn) continue;
        if (strcmp(cn, name) != 0) continue;

        int s = zk_score_class_name(cn);
        if (s > bestScore) { bestScore = s; best = k; }
    }
    return best;
}

Il2CppClass *zk_rt_find_class_in(const char *assembly, const char *ns, const char *name)
{
    zk_build_table();
    if (!name) return NULL;

    for (int i = 0; i < g_tableLen; i++) {
        Il2CppClass *k = g_table[i].klass;
        if (ns && strcmp(zk_rt_class_ns(k), ns) != 0) continue;
        const char *cn = zk_rt_class_name(k);
        if (!cn || strcmp(cn, name) != 0) continue;
        if (assembly && g_table[i].image && strcmp(g_table[i].image, assembly) != 0) continue;
        return k;
    }
    return NULL;
}

/* ============================================================
   字段
   ============================================================ */

FieldInfo *zk_rt_field_first(Il2CppClass *k, void **iter)
{
    if (!k || !p_class_get_fields || !iter) return NULL;
    *iter = NULL;
    return p_class_get_fields(k, iter);
}

const char *zk_rt_field_name(FieldInfo *f)
{
    if (!f || !p_field_get_name) return NULL;
    return p_field_get_name(f);
}

size_t zk_rt_field_offset(FieldInfo *f)
{
    if (!f || !p_field_get_offset) return (size_t)-1;
    return p_field_get_offset(f);
}

bool zk_rt_field_is_static(FieldInfo *f)
{
    if (!f || !p_field_get_flags) return false;
    return (p_field_get_flags(f) & FIELD_ATTRIBUTE_STATIC) != 0;
}

/* 类型名缓存:il2cpp_type_get_name 每次都新分配,不缓存会一直涨内存 */
#define ZK_TCACHE 1024
static struct { const void *key; char *name; } g_tcache[ZK_TCACHE];

static const char *zk_type_name(const void *type)
{
    if (!type || !p_type_get_name) return "?";

    int slot = ((uintptr_t)type >> 4) % ZK_TCACHE;
    if (g_tcache[slot].key == type && g_tcache[slot].name) return g_tcache[slot].name;

    char *raw = p_type_get_name(type);
    if (!raw) return "?";

    char *copy = strdup(raw);
    if (p_il2cpp_free) p_il2cpp_free(raw);

    if (g_tcache[slot].name) free(g_tcache[slot].name);
    g_tcache[slot].key  = type;
    g_tcache[slot].name = copy;

    return copy;
}

const char *zk_rt_field_type(FieldInfo *f)
{
    if (!f || !p_field_get_type) return "?";
    return zk_type_name(p_field_get_type(f));
}

FieldInfo *zk_rt_find_field(Il2CppClass *k, const char *name)
{
    if (!k || !name) return NULL;

    Il2CppClass *cur = k;
    int guard = 0;
    while (cur && guard++ < 16) {
        if (p_class_get_field_from_name) {
            FieldInfo *f = p_class_get_field_from_name(cur, name);
            if (f) return f;
        }
        cur = zk_rt_class_parent(cur);
    }
    return NULL;
}

void *zk_rt_field_addr(void *obj, FieldInfo *f)
{
    if (!obj || !f) return NULL;
    size_t off = zk_rt_field_offset(f);
    if (off == (size_t)-1) return NULL;
    return (uint8_t *)obj + off;
}

void *zk_rt_field_get_obj(void *obj, FieldInfo *f)
{
    void *addr = zk_rt_field_addr(obj, f);
    if (!addr) return NULL;
    void *v = NULL;
    if (!zk_safe_read(addr, &v, sizeof(v))) return NULL;
    return v;
}

bool zk_rt_field_set_obj(void *obj, FieldInfo *f, void *v)
{
    void *addr = zk_rt_field_addr(obj, f);
    if (!addr) return false;
    return zk_mem_write(addr, &v, sizeof(v));
}

bool zk_rt_field_static_get(FieldInfo *f, void *out)
{
    if (!f || !out || !p_field_static_get) return false;
    p_field_static_get(f, out);
    return true;
}

bool zk_rt_field_static_set(FieldInfo *f, const void *v)
{
    if (!f || !v || !p_field_static_set) return false;
    p_field_static_set(f, (void *)v);
    return true;
}

float zk_rt_field_get_float(void *obj, FieldInfo *f)
{
    void *addr = zk_rt_field_addr(obj, f);
    float v = 0;
    if (!addr) return 0;
    zk_safe_read(addr, &v, sizeof(v));
    return v;
}

void zk_rt_field_set_float(void *obj, FieldInfo *f, float v)
{
    void *addr = zk_rt_field_addr(obj, f);
    if (addr) zk_mem_write(addr, &v, sizeof(v));
}

int32_t zk_rt_field_get_int(void *obj, FieldInfo *f)
{
    void *addr = zk_rt_field_addr(obj, f);
    int32_t v = 0;
    if (!addr) return 0;
    zk_safe_read(addr, &v, sizeof(v));
    return v;
}

void zk_rt_field_set_int(void *obj, FieldInfo *f, int32_t v)
{
    void *addr = zk_rt_field_addr(obj, f);
    if (addr) zk_mem_write(addr, &v, sizeof(v));
}

bool zk_rt_field_get_bool(void *obj, FieldInfo *f)
{
    void *addr = zk_rt_field_addr(obj, f);
    uint8_t v = 0;
    if (!addr) return false;
    zk_safe_read(addr, &v, sizeof(v));
    return v != 0;
}

void zk_rt_field_set_bool(void *obj, FieldInfo *f, bool v)
{
    void *addr = zk_rt_field_addr(obj, f);
    uint8_t b = v ? 1 : 0;
    if (addr) zk_mem_write(addr, &b, sizeof(b));
}

/* ============================================================
   方法
   ============================================================ */

MethodInfo *zk_rt_method_first(Il2CppClass *k, void **iter)
{
    if (!k || !p_class_get_methods || !iter) return NULL;
    *iter = NULL;
    return (MethodInfo *)p_class_get_methods(k, iter);
}

const char *zk_rt_method_name(MethodInfo *m)
{
    if (!m || !p_method_get_name) return NULL;
    return p_method_get_name(m);
}

int zk_rt_method_argc(MethodInfo *m)
{
    if (!m || !p_method_get_param_count) return -1;
    return (int)p_method_get_param_count(m);
}

const char *zk_rt_method_ret(MethodInfo *m)
{
    if (!m || !p_method_get_return_type) return "?";
    return zk_type_name(p_method_get_return_type(m));
}

void *zk_rt_method_ptr(MethodInfo *m)
{
    if (!m) return NULL;
    void *p = m->methodPointer;
    if (!p) p = m->virtualMethodPointer;
    return p;
}

MethodInfo *zk_rt_class_method(Il2CppClass *k, const char *name, int argc)
{
    if (!k || !name) return NULL;
    if (!p_class_get_method_from_name) return NULL;

    /* 先按精确 argc 找,找不到再把所有重载过一遍 */
    MethodInfo *m = p_class_get_method_from_name(k, name, argc);
    if (m) return m;

    void *iter = NULL;
    MethodInfo *cur = NULL;
    while ((cur = zk_rt_method_first(k, &iter)) != NULL) {
        const char *n = zk_rt_method_name(cur);
        if (n && strcmp(n, name) == 0) {
            if (argc < 0 || zk_rt_method_argc(cur) == argc) return cur;
        }
    }
    return NULL;
}

MethodInfo *zk_rt_obj_method(void *obj, const char *name, int argc)
{
    Il2CppClass *k = zk_rt_obj_class(obj);
    int guard = 0;
    while (k && guard++ < 16) {
        MethodInfo *m = zk_rt_class_method(k, name, argc);
        if (m) return m;
        k = zk_rt_class_parent(k);
    }
    return NULL;
}

void *zk_rt_invoke(MethodInfo *m, void *obj, void **args)
{
    if (!m || !p_runtime_invoke) return NULL;
    zk_rt_attach_thread();
    return p_runtime_invoke(m, obj, args, NULL);
}

void *zk_rt_invoke_on(void *obj, const char *name, int argc, void **args)
{
    MethodInfo *m = zk_rt_obj_method(obj, name, argc);
    if (!m) return NULL;
    return zk_rt_invoke(m, obj, args);
}

/* ------------------------------------------------------------
   值类型返回值处理
   —— il2cpp_runtime_invoke 声明返回 Il2CppObject*,所以 Vector3 这种
      值类型返回是【装箱】过的。正确做法是过一遍 il2cpp_object_unbox。
      不同版本里 unbox 的头部长度也有差异,这里两种解释都试一遍,
      哪个读出来是正常数值就用哪个(比猜版本靠谱)。
   ------------------------------------------------------------ */

void *zk_rt_unbox(void *obj)
{
    if (!obj) return NULL;
    if (p_object_unbox) return p_object_unbox(obj);
    /* 没有 unbox 符号时的兜底:16 字节头后就是数据 */
    return (uint8_t *)obj + 16;
}

static bool zk_float_ok(float f)
{
    if (f != f) return false;                 /* NaN */
    if (f > 1e9f || f < -1e9f) return false;  /* inf / 离谱值 */
    return true;
}

ZKVec3 zk_rt_read_vec3_ret(void *ret)
{
    ZKVec3 raw  = { 0, 0, 0 };
    ZKVec3 unboxed = { 0, 0, 0 };

    if (!ret) return raw;

    bool rawOK = false, unboxOK = false;

    if (zk_safe_read(ret, &raw, sizeof(raw))) {
        rawOK = zk_float_ok(raw.x) && zk_float_ok(raw.y) && zk_float_ok(raw.z);
    }

    void *data = zk_rt_unbox(ret);
    if (data && zk_safe_read(data, &unboxed, sizeof(unboxed))) {
        unboxOK = zk_float_ok(unboxed.x) && zk_float_ok(unboxed.y) && zk_float_ok(unboxed.z);
    }

    /* 原始指针看起来就是个坐标 → 说明这个版本没装箱,直接用 */
    if (rawOK && !unboxOK) return raw;
    if (unboxOK) return unboxed;
    return raw;
}

float zk_rt_read_float_ret(void *ret)
{
    float v = 0;
    if (!ret) return 0;

    if (zk_safe_read(ret, &v, sizeof(v)) && zk_float_ok(v)) return v;

    void *data = zk_rt_unbox(ret);
    if (data && zk_safe_read(data, &v, sizeof(v)) && zk_float_ok(v)) return v;

    return 0;
}

/* ============================================================
   通用
   ============================================================ */

Il2CppClass *zk_rt_obj_class(void *obj)
{
    if (!obj || !p_object_get_class) return NULL;
    return p_object_get_class(obj);
}

const char *zk_rt_obj_class_name(void *obj)
{
    Il2CppClass *k = zk_rt_obj_class(obj);
    if (!k) return NULL;
    return zk_rt_class_name(k);
}

void *zk_rt_type_obj(Il2CppClass *k)
{
    if (!k || !p_class_get_type || !p_type_get_object) return NULL;
    const void *t = p_class_get_type(k);
    if (!t) return NULL;
    return p_type_get_object(t);
}

int zk_rt_array_len(void *arr)
{
    if (!arr || !p_array_length) return 0;
    return (int)p_array_length(arr);
}

void *zk_rt_array_at(void *arr, int i)
{
    if (!arr || i < 0) return NULL;
    if (i >= zk_rt_array_len(arr)) return NULL;

    void *item = NULL;
    uint8_t *p = (uint8_t *)arr + ZK_ARRAY_VECTOR_OFFSET + (size_t)i * sizeof(void *);
    if (!zk_safe_read(p, &item, sizeof(item))) return NULL;
    return item;
}

/* ============================================================
   坐标
   ============================================================ */

void *zk_rt_get_transform(void *component)
{
    if (!component) return NULL;
    void *t = zk_rt_invoke_on(component, "get_transform", 0, NULL);
    return t;
}

ZKVec3 zk_rt_get_pos(void *componentOrTransform)
{
    ZKVec3 v = { 0, 0, 0 };
    if (!componentOrTransform) return v;

    void *transform = componentOrTransform;

    /* 传进来的是 Component,先转 Transform */
    Il2CppClass *k = zk_rt_obj_class(componentOrTransform);
    const char *kn = zk_rt_class_name(k);
    if (kn && strcmp(kn, "Transform") != 0) {
        void *t = zk_rt_get_transform(componentOrTransform);
        if (t) transform = t;
    }

    /*
     * Transform.get_position 是值类型返回。
     * il2cpp_runtime_invoke 对值类型返回的是装箱对象,读的时候要兼容两种解释。
     */
    void *ret = zk_rt_invoke_on(transform, "get_position", 0, NULL);
    return zk_rt_read_vec3_ret(ret);
}

bool zk_rt_set_pos(void *transform, ZKVec3 p)
{
    if (!transform) return false;
    MethodInfo *m = zk_rt_obj_method(transform, "set_position", 1);
    if (!m) return false;

    /* 值类型参数:传值本身的地址 */
    void *args[1] = { &p };
    zk_rt_invoke(m, transform, args);
    return true;
}

/* ============================================================
   打补丁
   ============================================================ */

typedef struct {
    void   *addr;
    uint8_t saved[8];
    bool    used;
} ZKPatchRec;

#define ZK_MAX_PATCHES 256
static ZKPatchRec g_patches[ZK_MAX_PATCHES];
static int g_patchCount = 0;

static int zk_patch_find(void *addr)
{
    for (int i = 0; i < ZK_MAX_PATCHES; i++) {
        if (g_patches[i].used && g_patches[i].addr == addr) return i;
    }
    return -1;
}

bool zk_rt_patch_method(MethodInfo *m, ZKRetKind kind)
{
    void *addr = zk_rt_method_ptr(m);
    if (!addr) return false;

    if (zk_patch_find(addr) >= 0) return true;   /* 已经打过 */

    int slot = -1;
    for (int i = 0; i < ZK_MAX_PATCHES; i++) {
        if (!g_patches[i].used) { slot = i; break; }
    }
    if (slot < 0) return false;

    if (!zk_patch_save(addr, g_patches[slot].saved)) return false;

    bool ok = false;
    switch (kind) {
        case ZK_RET_VOID:
            ok = zk_patch_ret(addr);
            break;
        case ZK_RET_TRUE:
            ok = zk_patch_return_true(addr);
            break;
        case ZK_RET_FALSE:
        case ZK_RET_ZERO_INT:
        default:
            ok = zk_patch_return_false(addr);
            break;
    }
    if (!ok) return false;

    g_patches[slot].addr = addr;
    g_patches[slot].used = true;
    if (slot >= g_patchCount) g_patchCount = slot + 1;
    return true;
}

bool zk_rt_unpatch_method(MethodInfo *m)
{
    void *addr = zk_rt_method_ptr(m);
    if (!addr) return false;

    int slot = zk_patch_find(addr);
    if (slot < 0) return false;

    bool ok = zk_patch_restore(addr, g_patches[slot].saved);
    g_patches[slot].used = false;
    return ok;
}

bool zk_rt_method_patched(MethodInfo *m)
{
    void *addr = zk_rt_method_ptr(m);
    if (!addr) return false;
    return zk_patch_find(addr) >= 0;
}

int zk_rt_patch_count(void)
{
    int n = 0;
    for (int i = 0; i < ZK_MAX_PATCHES; i++) if (g_patches[i].used) n++;
    return n;
}
