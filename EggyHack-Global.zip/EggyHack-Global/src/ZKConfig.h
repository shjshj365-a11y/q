//
//  ZKConfig.h
//  全局配置
//

#ifndef ZK_CONFIG_H
#define ZK_CONFIG_H

/* ============================================================
   日志
   —— iOS 上 NSLog 是反作弊最爱抓的特征之一(它 hook 了 NSLog / 遍历 oslog)。
      发布版必须 0。自己调试的时候改成 1 再编一份。
   ============================================================ */

#ifndef ZK_DEBUG
#define ZK_DEBUG 0
#endif

#if ZK_DEBUG
#import <Foundation/Foundation.h>
#define ZKLOG(fmt, ...) NSLog(@"[EggyHack] " fmt, ##__VA_ARGS__)
#else
#define ZKLOG(fmt, ...) do {} while (0)
#endif

/* ============================================================
   自身隐身名
   —— 注入到包里的 dylib 文件名建议用这个,别叫 hack / cheat / eggy。
      编译脚本会自动把 LC_ID_DYLIB 也改成中性路径。
   ============================================================ */

#define ZK_STEALTH_DYLIB_NAME   "libMediaToolbox_x.dylib"

/* ============================================================
   默认功能开关(悬浮窗里可以随时改)
   ============================================================ */

#define ZK_DEF_ESP           0   /* 透视:默认关,进去自己开 */
#define ZK_DEF_FLY           0   /* 飞天 */
#define ZK_DEF_NOCLIP        0   /* 遁地 / 穿墙 */
#define ZK_DEF_SPEED         0   /* 加速 */
#define ZK_DEF_NOCOOLDOWN    0   /* 无冷却 */
#define ZK_DEF_ANTIBAN       1   /* 防封:默认开 */

/* 数值安全范围 —— 超了服务端一眼就看出来,这里直接钳死 */
#define ZK_SPEED_MIN         1.0f
#define ZK_SPEED_MAX         2.5f
#define ZK_SPEED_DEFAULT     1.6f

#define ZK_FLY_MIN           0.5f
#define ZK_FLY_MAX           8.0f
#define ZK_FLY_DEFAULT       3.0f

/* 飞天/遁地每次写位置的间隔(秒)。太频繁=异常数据,服务端好抓 */
#define ZK_MOVE_INTERVAL     0.05

/* 透视画框的最大距离,超过不画 */
#define ZK_ESP_MAX_DIST      260.0f

/* 启动后延迟多久才开始动手(避开启动期的自检窗口) */
#define ZK_START_DELAY       3.0

#endif /* ZK_CONFIG_H */
